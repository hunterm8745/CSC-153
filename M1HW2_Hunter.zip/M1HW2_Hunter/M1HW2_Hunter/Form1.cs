﻿/**
* Febuary 7, 2018
* CSC 153
* Matthew Hunter
* Display card name when clicked
*/

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace M1HW2_Hunter
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void twoPictureBox_Click(object sender, EventArgs e)
        {
            outputLabel.Text = "Two of Clubs";
        }

        private void fivePictureBox_Click(object sender, EventArgs e)
        {
            outputLabel.Text = "Five of Hearts";
        }

        private void kingPictureBox_Click(object sender, EventArgs e)
        {
            outputLabel.Text = "King of Diamonds";
        }

        private void queenPictureBox_Click(object sender, EventArgs e)
        {
            outputLabel.Text = "Queen of Spades";
        }

        private void jokerPictureBox_Click(object sender, EventArgs e)
        {
            outputLabel.Text = "Red Joker";
        }
    }
}
