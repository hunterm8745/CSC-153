﻿namespace M1HW2_Hunter
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.twoPictureBox = new System.Windows.Forms.PictureBox();
            this.fivePictureBox = new System.Windows.Forms.PictureBox();
            this.kingPictureBox = new System.Windows.Forms.PictureBox();
            this.queenPictureBox = new System.Windows.Forms.PictureBox();
            this.jokerPictureBox = new System.Windows.Forms.PictureBox();
            this.outputLabel = new System.Windows.Forms.Label();
            this.instructionText = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.twoPictureBox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.fivePictureBox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.kingPictureBox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.queenPictureBox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.jokerPictureBox)).BeginInit();
            this.SuspendLayout();
            // 
            // twoPictureBox
            // 
            this.twoPictureBox.Image = ((System.Drawing.Image)(resources.GetObject("twoPictureBox.Image")));
            this.twoPictureBox.Location = new System.Drawing.Point(12, 47);
            this.twoPictureBox.Name = "twoPictureBox";
            this.twoPictureBox.Size = new System.Drawing.Size(187, 256);
            this.twoPictureBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.twoPictureBox.TabIndex = 0;
            this.twoPictureBox.TabStop = false;
            this.twoPictureBox.Click += new System.EventHandler(this.twoPictureBox_Click);
            // 
            // fivePictureBox
            // 
            this.fivePictureBox.Image = ((System.Drawing.Image)(resources.GetObject("fivePictureBox.Image")));
            this.fivePictureBox.Location = new System.Drawing.Point(205, 47);
            this.fivePictureBox.Name = "fivePictureBox";
            this.fivePictureBox.Size = new System.Drawing.Size(186, 256);
            this.fivePictureBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.fivePictureBox.TabIndex = 1;
            this.fivePictureBox.TabStop = false;
            this.fivePictureBox.Click += new System.EventHandler(this.fivePictureBox_Click);
            // 
            // kingPictureBox
            // 
            this.kingPictureBox.Image = ((System.Drawing.Image)(resources.GetObject("kingPictureBox.Image")));
            this.kingPictureBox.Location = new System.Drawing.Point(397, 47);
            this.kingPictureBox.Name = "kingPictureBox";
            this.kingPictureBox.Size = new System.Drawing.Size(183, 256);
            this.kingPictureBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.kingPictureBox.TabIndex = 2;
            this.kingPictureBox.TabStop = false;
            this.kingPictureBox.Click += new System.EventHandler(this.kingPictureBox_Click);
            // 
            // queenPictureBox
            // 
            this.queenPictureBox.Image = ((System.Drawing.Image)(resources.GetObject("queenPictureBox.Image")));
            this.queenPictureBox.Location = new System.Drawing.Point(586, 47);
            this.queenPictureBox.Name = "queenPictureBox";
            this.queenPictureBox.Size = new System.Drawing.Size(181, 256);
            this.queenPictureBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.queenPictureBox.TabIndex = 3;
            this.queenPictureBox.TabStop = false;
            this.queenPictureBox.Click += new System.EventHandler(this.queenPictureBox_Click);
            // 
            // jokerPictureBox
            // 
            this.jokerPictureBox.Image = ((System.Drawing.Image)(resources.GetObject("jokerPictureBox.Image")));
            this.jokerPictureBox.Location = new System.Drawing.Point(773, 47);
            this.jokerPictureBox.Name = "jokerPictureBox";
            this.jokerPictureBox.Size = new System.Drawing.Size(183, 256);
            this.jokerPictureBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.jokerPictureBox.TabIndex = 4;
            this.jokerPictureBox.TabStop = false;
            this.jokerPictureBox.Click += new System.EventHandler(this.jokerPictureBox_Click);
            // 
            // outputLabel
            // 
            this.outputLabel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.outputLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.outputLabel.Location = new System.Drawing.Point(12, 317);
            this.outputLabel.Name = "outputLabel";
            this.outputLabel.Size = new System.Drawing.Size(944, 42);
            this.outputLabel.TabIndex = 5;
            this.outputLabel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // instructionText
            // 
            this.instructionText.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.instructionText.Location = new System.Drawing.Point(406, 9);
            this.instructionText.Name = "instructionText";
            this.instructionText.Size = new System.Drawing.Size(174, 23);
            this.instructionText.TabIndex = 6;
            this.instructionText.Text = "Click a card to see its name!";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(969, 368);
            this.Controls.Add(this.instructionText);
            this.Controls.Add(this.outputLabel);
            this.Controls.Add(this.jokerPictureBox);
            this.Controls.Add(this.queenPictureBox);
            this.Controls.Add(this.kingPictureBox);
            this.Controls.Add(this.fivePictureBox);
            this.Controls.Add(this.twoPictureBox);
            this.Name = "Form1";
            this.Text = "Form1";
            ((System.ComponentModel.ISupportInitialize)(this.twoPictureBox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.fivePictureBox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.kingPictureBox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.queenPictureBox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.jokerPictureBox)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.PictureBox twoPictureBox;
        private System.Windows.Forms.PictureBox fivePictureBox;
        private System.Windows.Forms.PictureBox kingPictureBox;
        private System.Windows.Forms.PictureBox queenPictureBox;
        private System.Windows.Forms.PictureBox jokerPictureBox;
        private System.Windows.Forms.Label outputLabel;
        private System.Windows.Forms.Label instructionText;
    }
}

