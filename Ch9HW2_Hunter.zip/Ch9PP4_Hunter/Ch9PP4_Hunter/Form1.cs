﻿/**
* May 12, 2018
* CSC 153
* Matthew Hunter
* Create, Hold, and Display infromation about employees
*/

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Ch9PP4_Hunter
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void displayButton_Click(object sender, EventArgs e)
        {
            //Create first employee object
            Employee emp = new Employee("Susan Meyers", 47899, "Accounting", "Vice President");

            //Create second employee object
            Employee emp2 = new Employee("Mark Jones", 39119, "IT", "Programmer");

            //Create third employee object
            Employee emp3 = new Employee("Joy Rogers", 81774, "Manufacturing", "Engineer");

            //Display employees
            empListBox.Items.Add(emp.Name + "       " + emp.id + "           " + emp.Dept + "            " + emp.Pos);
            empListBox.Items.Add(emp2.Name + "           " + emp2.id + "           " + emp2.Dept + "                           " + emp2.Pos);
            empListBox.Items.Add(emp3.Name + "            " + emp3.id + "           " + emp3.Dept + "       " + emp3.Pos);
        }

        private void exitButton_Click(object sender, EventArgs e)
        {
            //Close the form
            this.Close();
        }
    }
}
