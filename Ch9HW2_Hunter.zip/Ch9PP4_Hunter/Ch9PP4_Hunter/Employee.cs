﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ch9PP4_Hunter
{
    class Employee
    {
        //Fields
        private string _name;
        private int _id;
        private string _dept;
        private string _pos;

        //Create constructor
        public Employee()
        {
            _name = "";
            _id = 0;
            _dept = "";
            _pos = "";
        }

        //Constructor
        public Employee(string name, int id, string dept, string pos)
        {
            _name = name;
            _id = id;
            _dept = dept;
            _pos = pos;
        }

        //Constructor
        public Employee(string name, int id)
        {
            _name = name;
            _id = id;
            _dept = "";
            _pos = "";
        }

        //Name property
        public string Name
        {
            get { return _name; }
            set { _name = value; }
        }

        //ID property
        public int id
        {
            get { return _id; }
            set { _id = value; }
        }

        //Department property
        public string Dept
        {
            get { return _dept; }
            set { _dept = value; }
        }

        //Position property
        public string Pos
        {
            get { return _pos; }
            set { _pos = value; }
        }
    }
}
