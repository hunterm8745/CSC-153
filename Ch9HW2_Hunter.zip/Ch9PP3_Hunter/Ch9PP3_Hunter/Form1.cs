﻿/**
* May 12, 2018
* CSC 153
* Matthew Hunter
* Create, hold , and display personal information
*/

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Ch9PP3_Hunter
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        //Create personal data for me
        private void GetMyData()
        {
            //Create new info object
            Info me = new Info();

            //Enter information
            me.Name = "Matthew Hunter";
            me.Address = "5555 King Road";
            me.Age = "23";
            me.Phone = "555-6525";

            //Display information
            infoListBox.Items.Add(me.Name + ", " + me.Address + ", " + me.Age + ", " + me.Phone);
        }

        //Create personal data for my friend
        private void GetFriend1Data()
        {
            //Create new info object
            Info friend1 = new Info();

            //Enter information
            friend1.Name = "Victor Slaughter";
            friend1.Address = "1788 Pine Tree Road";
            friend1.Age = "30";
            friend1.Phone = "555-7718";

            //Display information
            infoListBox.Items.Add(friend1.Name + ", " + friend1.Address + ", " + friend1.Age + ", " + friend1.Phone);
        }

        //Create personal data for my second friend
        private void GetFriend2Data()
        {
            //Create new info object
            Info friend2 = new Info();

            //Enter information
            friend2.Name = "Pearce Smith";
            friend2.Address = "858 Church Hill Drive";
            friend2.Age = "24";
            friend2.Phone = "555-2295";

            //Display information
            infoListBox.Items.Add(friend2.Name + ", " + friend2.Address + ", " + friend2.Age + ", " + friend2.Phone);
        }

        private void displayButton_Click(object sender, EventArgs e)
        {
            //Call Other information Methods
            GetMyData();            //Call the GetMyData method
            GetFriend1Data();       //Call the GetFriend1Data method
            GetFriend2Data();       //Call the GetFriend2Data method
        }

        private void exitButton_Click(object sender, EventArgs e)
        {
            //Close the form
            this.Close();
        }
    }
}
