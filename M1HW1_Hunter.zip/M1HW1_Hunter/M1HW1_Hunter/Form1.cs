﻿/**
* January 31, 2018
* CSC 153
* Matthew Hunter
* Translate three latin words into english
*/

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace M1HW1_Hunter
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void sinisterButton_Click(object sender, EventArgs e)
        {
            //Display "Left"
            translationLabel.Text = "Left";
        }

        private void dexterButton_Click(object sender, EventArgs e)
        {
            //Display "Right"
            translationLabel.Text = "Right";
        }

        private void mediumButton_Click(object sender, EventArgs e)
        {
            //Display "Center
            translationLabel.Text = "Center";
        }
    }
}
