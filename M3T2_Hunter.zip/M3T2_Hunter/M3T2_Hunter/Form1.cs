﻿/**
* Febuary 19, 2018
* CSC 153
* Matthew Hunter
* Calculate MPG with user given miles and gallons
*/

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace M3T2_Hunter
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void calculateButton_Click(object sender, EventArgs e)
        {
            double miles;       //Hold miles driven
            double gallons;     //Hold gallons used
            double mpg;         //Hold mpg

            //Validate milesTextBox
            if (double.TryParse(milesTextBox.Text, out miles))
            {
                //Validate gallonsTextBox
                if (double.TryParse(gallonsTextBox.Text, out gallons))
                {
                    //Calculate MPG
                    mpg = miles / gallons;

                    //Display MPG to mpgLabel
                    mpgLabel.Text = mpg.ToString("n1");
                }
                else
                {
                    //Display error message for gallonsTextBox
                    MessageBox.Show("Invalid input for gallons.");
                }
            }
            else
            {
                //Display error message for milesTextBox
                MessageBox.Show("Invalid input for miles.");
            }
        }

        private void exitButton_Click(object sender, EventArgs e)
        {
            //Close the form
            this.Close();
        }
    }
}
