﻿/**
* January 31, 2018
* CSC 153
* Group 4
* Show either side of a coin
*/

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace M1HW3_Group4
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void showHeadsButton_Click(object sender, EventArgs e)
        {
            //Make heads visible and tails invisible
            showHeadsPictureBox.Visible = true;
            showTailsPictureBox.Visible = false;
        }

        private void ShowTailsButton_Click(object sender, EventArgs e)
        {
            //Make tails visible and tails invisible
            showHeadsPictureBox.Visible = false;
            showTailsPictureBox.Visible = true;
        }

        private void ExitButton_Click(object sender, EventArgs e)
        {
            //Close the program
            this.Close();
        }
    }
}
