﻿namespace M1HW3_Group4
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.showHeadsPictureBox = new System.Windows.Forms.PictureBox();
            this.showTailsPictureBox = new System.Windows.Forms.PictureBox();
            this.showHeadsButton = new System.Windows.Forms.Button();
            this.ShowTailsButton = new System.Windows.Forms.Button();
            this.ExitButton = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.showHeadsPictureBox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.showTailsPictureBox)).BeginInit();
            this.SuspendLayout();
            // 
            // showHeadsPictureBox
            // 
            this.showHeadsPictureBox.Image = ((System.Drawing.Image)(resources.GetObject("showHeadsPictureBox.Image")));
            this.showHeadsPictureBox.Location = new System.Drawing.Point(12, 12);
            this.showHeadsPictureBox.Name = "showHeadsPictureBox";
            this.showHeadsPictureBox.Size = new System.Drawing.Size(110, 110);
            this.showHeadsPictureBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.showHeadsPictureBox.TabIndex = 0;
            this.showHeadsPictureBox.TabStop = false;
            this.showHeadsPictureBox.Visible = false;
            // 
            // showTailsPictureBox
            // 
            this.showTailsPictureBox.Image = ((System.Drawing.Image)(resources.GetObject("showTailsPictureBox.Image")));
            this.showTailsPictureBox.Location = new System.Drawing.Point(139, 12);
            this.showTailsPictureBox.Name = "showTailsPictureBox";
            this.showTailsPictureBox.Size = new System.Drawing.Size(110, 110);
            this.showTailsPictureBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.showTailsPictureBox.TabIndex = 1;
            this.showTailsPictureBox.TabStop = false;
            this.showTailsPictureBox.Visible = false;
            // 
            // showHeadsButton
            // 
            this.showHeadsButton.Location = new System.Drawing.Point(12, 140);
            this.showHeadsButton.Name = "showHeadsButton";
            this.showHeadsButton.Size = new System.Drawing.Size(75, 37);
            this.showHeadsButton.TabIndex = 2;
            this.showHeadsButton.Text = "Show Heads";
            this.showHeadsButton.UseVisualStyleBackColor = true;
            this.showHeadsButton.Click += new System.EventHandler(this.showHeadsButton_Click);
            // 
            // ShowTailsButton
            // 
            this.ShowTailsButton.Location = new System.Drawing.Point(93, 140);
            this.ShowTailsButton.Name = "ShowTailsButton";
            this.ShowTailsButton.Size = new System.Drawing.Size(75, 37);
            this.ShowTailsButton.TabIndex = 3;
            this.ShowTailsButton.Text = "Show Tails";
            this.ShowTailsButton.UseVisualStyleBackColor = true;
            this.ShowTailsButton.Click += new System.EventHandler(this.ShowTailsButton_Click);
            // 
            // ExitButton
            // 
            this.ExitButton.Location = new System.Drawing.Point(174, 140);
            this.ExitButton.Name = "ExitButton";
            this.ExitButton.Size = new System.Drawing.Size(75, 37);
            this.ExitButton.TabIndex = 4;
            this.ExitButton.Text = "Exit";
            this.ExitButton.UseVisualStyleBackColor = true;
            this.ExitButton.Click += new System.EventHandler(this.ExitButton_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(264, 202);
            this.Controls.Add(this.ExitButton);
            this.Controls.Add(this.ShowTailsButton);
            this.Controls.Add(this.showHeadsButton);
            this.Controls.Add(this.showTailsPictureBox);
            this.Controls.Add(this.showHeadsPictureBox);
            this.Name = "Form1";
            this.Text = "Heads or Tails";
            ((System.ComponentModel.ISupportInitialize)(this.showHeadsPictureBox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.showTailsPictureBox)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.PictureBox showHeadsPictureBox;
        private System.Windows.Forms.PictureBox showTailsPictureBox;
        private System.Windows.Forms.Button showHeadsButton;
        private System.Windows.Forms.Button ShowTailsButton;
        private System.Windows.Forms.Button ExitButton;
    }
}

