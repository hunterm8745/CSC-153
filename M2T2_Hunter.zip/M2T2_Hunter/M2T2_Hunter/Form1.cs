﻿/**
* Febuary 12, 2018
* CSC 153
* Matthew Hunter
* Calculate average grade from three tests
*/

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace M2T2_Hunter
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void calculateButton_Click(object sender, EventArgs e)
        {
            try
            {
                double test1;       //Hold Test 1
                double test2;       //Hold Test 2
                double test3;       //Hold Test 3
                double average;     //Hold the average

                //assign test1 and change it to a double
                test1 = double.Parse(test1TextBox.Text);

                //assign test2 and change it to a double
                test2 = double.Parse(test2TextBox.Text);

                //assign test3 and change it to a double
                test3 = double.Parse(test3TextBox.Text);

                //Calculate average
                average = (test1 + test2 + test3) / 3.0;

                //Display Average
                averageLabel.Text = average.ToString();
            }
            catch (Exception ex)
            {
                //Display default error message
                MessageBox.Show(ex.Message);
            }
        }

        private void clearButton_Click(object sender, EventArgs e)
        {
            //Clear all input and output controls
            test1TextBox.Text = "";
            test2TextBox.Text = "";
            test3TextBox.Text = "";
            averageLabel.Text = "";
        }

        private void exitButton_Click(object sender, EventArgs e)
        {
            //Close the program
            this.Close();
        }
    }
}
