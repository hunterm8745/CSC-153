﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace M4HW3_Group6
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void loadButton_Click(object sender, EventArgs e)
        {
            int line = 0;               //Hold read line
            int total = 0;              //Hold total of all numbers in file
            int x = 0;                  //Hold incremental count of all numbers in file
            StreamReader inputFile;     //Variable for selected file

            try
            {
                //Check to see if a file was chosen
                if (openFile.ShowDialog() == DialogResult.OK)
                {
                    //)pen chosen file
                    inputFile = File.OpenText(openFile.FileName);

                    //Create a while loop till all data is read
                    while (!inputFile.EndOfStream)
                    {
                        //Parse read line then assign it to line variable
                        line = int.Parse(inputFile.ReadLine());

                        //Add line variable to compound total
                        total += line;

                        //Increment x for every line read
                        x++;

                        //Display line variable
                        numberListBox.Items.Add(line);
                    }
                }
                else
                {
                    MessageBox.Show("Operation Canceled");
                }

                //Display x(number of intigers in the file)
                numberLabel.Text = x.ToString();

                //Display total of all numbers in file
                totalLabel.Text = total.ToString();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void clearButton_Click(object sender, EventArgs e)
        {
            numberListBox.Items.Clear();
            numberLabel.Text = "";
            totalLabel.Text = "";
        }

        private void exitButton_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
