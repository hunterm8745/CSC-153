﻿/**
* March 12, 2018
* CSC 153
* Matthew Hunter
* Display organism numbers after a given amount of days
*/

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace M4HW1_Hunter
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void calculateButton_Click(object sender, EventArgs e)
        {
            try
            {
                double orgStart = double.Parse(startTextBox.Text);                  //Hold starting organism number
                double increase = (double.Parse(increaseTextBox.Text) / 100);       //Hold percentage increase of organisms
                double days = double.Parse(daysTextBox.Text);                       //Hold number of days organisms increase
                double orgEnd = orgStart;                                           //Hold end number of organisms
                int x = 1;                                                              //Increment variable

                organismListBox.Items.Add(x + "                                         " + orgEnd);
                
                //Calculate and display orgEnd for the amount of days given
                for (x = 1; x <= days; x++)
                {
                        orgEnd += (orgEnd * increase);

                        organismListBox.Items.Add(x + "                                         " + orgEnd);
                }
            }
            catch(Exception ex)
            {
                //Display error message
                MessageBox.Show(ex.Message);
            }
        }

        private void clearButton_Click(object sender, EventArgs e)
        {
            //Clear all applicable fields
            startTextBox.Text = "";
            increaseTextBox.Text = "";
            daysTextBox.Text = "";
            organismListBox.Items.Clear();
        }

        private void exitButton_Click(object sender, EventArgs e)
        {
            //Close the form
            this.Close();
        }
    }
}
