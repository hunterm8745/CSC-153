﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Ch9HW3_Hunter
{
    public partial class confirmationForm : Form
    {
        public confirmationForm()
        {
            InitializeComponent();
        }

        private void confirmButton_Click(object sender, EventArgs e)
        {
            mealAndDormForm mdForm = new mealAndDormForm();

            //Close mdForm
            mdForm.Close();

            //Close this form
            this.Close();
        }

        private void cancelButton_Click(object sender, EventArgs e)
        {
            //Close this form but not the first form
            this.Close();
        }
    }
}
