﻿/**
* May 12, 2018
* CSC 153
* Matthew Hunter
* Create form for meal plans and dormitory cost
*/

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Ch9HW3_Hunter
{
    public partial class mealAndDormForm : Form
    {
        int total = 0;

        public mealAndDormForm()
        {
            InitializeComponent();
        }

        private void confirmButton_Click(object sender, EventArgs e)
        {
            confirmationForm conForm = new confirmationForm();

            //Check selected item from item list
            //Then display text and calculate total
            if (dormListBox.SelectedIndex == 0)
            {
                conForm.dormLabel.Text = "$1,500 per semester";

                total += 1500;
            }

            if (dormListBox.SelectedIndex == 1)
            {
                conForm.dormLabel.Text = "$1,600 per semester";

                total += 1600;
            }

            if (dormListBox.SelectedIndex == 2)
            {
                conForm.dormLabel.Text = "$1,800 per semester";

                total += 1800;
            }

            if (dormListBox.SelectedIndex == 3)
            {
                conForm.dormLabel.Text = "$2,500 per semester";

                total += 2500;
            }

            if (mealListBox.SelectedIndex == 0)
            {
                conForm.mealLabel.Text = "$600 per semester";

                total += 600;
            }

            if (mealListBox.SelectedIndex == 1)
            {
                conForm.mealLabel.Text = "$1,200 per semester";

                total += 1200;
            }

            if (mealListBox.SelectedIndex == 2)
            {
                conForm.mealLabel.Text = "$1,700 per semester";

                total += 1700;
            }

            //Display total
            conForm.totalLabel.Text = "$" + total.ToString() + " per semester";

            //Display the Confirmation form
            conForm.ShowDialog();
        }

        private void exitButton_Click(object sender, EventArgs e)
        {
            //Close the form
            this.Close();
        }
    }
}
