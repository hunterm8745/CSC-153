﻿/**
* March 28, 2018
* CSC 153
* Matthew Hunter
* Display a picture of dice that corrispond to a randomly generated number
*/

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace M4HW2_Hunter
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void rollButton_Click(object sender, EventArgs e)
        {
            //Create variables to hold random intigers
            int die1;
            int die2;

            //Create new Random
            Random rand = new Random();

            //Set all PictureBoxes to invisible
            die1PictureBox.Visible = false;
            die2PictureBox.Visible = false;
            die3PictureBox.Visible = false;
            die4PictureBox.Visible = false;
            die5PictureBox.Visible = false;
            die6PictureBox.Visible = false;
            die1PictureBox2.Visible = false;
            die2PictureBox2.Visible = false;
            die3PictureBox2.Visible = false;
            die4PictureBox2.Visible = false;
            die5PictureBox2.Visible = false;
            die6PictureBox2.Visible = false;

            //Set random numbers to variables
            die1 = rand.Next(1, 6);
            die2 = rand.Next(1, 6);

            //Set visibility of picture corosponding to random number in die1
            switch (die1)
            {
                case 1:
                    die1PictureBox.Visible = true;
                    break;
                case 2:
                    die2PictureBox.Visible = true;
                    break;
                case 3:
                    die3PictureBox.Visible = true;
                    break;
                case 4:
                    die4PictureBox.Visible = true;
                    break;
                case 5:
                    die5PictureBox.Visible = true;
                    break;
                case 6:
                    die6PictureBox.Visible = true;
                    break;
            }

            //Set visibility of picture corosponding to random number in die2
            switch (die2)
            {
                case 1:
                    die1PictureBox2.Visible = true;
                    break;
                case 2:
                    die2PictureBox2.Visible = true;
                    break;
                case 3:
                    die3PictureBox2.Visible = true;
                    break;
                case 4:
                    die4PictureBox2.Visible = true;
                    break;
                case 5:
                    die5PictureBox2.Visible = true;
                    break;
                case 6:
                    die6PictureBox2.Visible = true;
                    break;
            }
        }

        private void exitButton_Click(object sender, EventArgs e)
        {
            //Close the Form
            this.Close();
        }
    }
}
