﻿namespace M4HW2_Hunter
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.die1PictureBox = new System.Windows.Forms.PictureBox();
            this.die2PictureBox = new System.Windows.Forms.PictureBox();
            this.die3PictureBox = new System.Windows.Forms.PictureBox();
            this.die4PictureBox = new System.Windows.Forms.PictureBox();
            this.die5PictureBox = new System.Windows.Forms.PictureBox();
            this.die6PictureBox = new System.Windows.Forms.PictureBox();
            this.die6PictureBox2 = new System.Windows.Forms.PictureBox();
            this.die5PictureBox2 = new System.Windows.Forms.PictureBox();
            this.die4PictureBox2 = new System.Windows.Forms.PictureBox();
            this.die3PictureBox2 = new System.Windows.Forms.PictureBox();
            this.die2PictureBox2 = new System.Windows.Forms.PictureBox();
            this.die1PictureBox2 = new System.Windows.Forms.PictureBox();
            this.rollButton = new System.Windows.Forms.Button();
            this.exitButton = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.die1PictureBox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.die2PictureBox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.die3PictureBox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.die4PictureBox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.die5PictureBox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.die6PictureBox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.die6PictureBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.die5PictureBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.die4PictureBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.die3PictureBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.die2PictureBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.die1PictureBox2)).BeginInit();
            this.SuspendLayout();
            // 
            // die1PictureBox
            // 
            this.die1PictureBox.Image = ((System.Drawing.Image)(resources.GetObject("die1PictureBox.Image")));
            this.die1PictureBox.Location = new System.Drawing.Point(12, 10);
            this.die1PictureBox.Name = "die1PictureBox";
            this.die1PictureBox.Size = new System.Drawing.Size(103, 104);
            this.die1PictureBox.TabIndex = 0;
            this.die1PictureBox.TabStop = false;
            this.die1PictureBox.Visible = false;
            // 
            // die2PictureBox
            // 
            this.die2PictureBox.Image = ((System.Drawing.Image)(resources.GetObject("die2PictureBox.Image")));
            this.die2PictureBox.Location = new System.Drawing.Point(12, 10);
            this.die2PictureBox.Name = "die2PictureBox";
            this.die2PictureBox.Size = new System.Drawing.Size(103, 104);
            this.die2PictureBox.TabIndex = 1;
            this.die2PictureBox.TabStop = false;
            this.die2PictureBox.Visible = false;
            // 
            // die3PictureBox
            // 
            this.die3PictureBox.Image = ((System.Drawing.Image)(resources.GetObject("die3PictureBox.Image")));
            this.die3PictureBox.Location = new System.Drawing.Point(12, 10);
            this.die3PictureBox.Name = "die3PictureBox";
            this.die3PictureBox.Size = new System.Drawing.Size(103, 104);
            this.die3PictureBox.TabIndex = 2;
            this.die3PictureBox.TabStop = false;
            this.die3PictureBox.Visible = false;
            // 
            // die4PictureBox
            // 
            this.die4PictureBox.Image = ((System.Drawing.Image)(resources.GetObject("die4PictureBox.Image")));
            this.die4PictureBox.Location = new System.Drawing.Point(12, 10);
            this.die4PictureBox.Name = "die4PictureBox";
            this.die4PictureBox.Size = new System.Drawing.Size(103, 104);
            this.die4PictureBox.TabIndex = 3;
            this.die4PictureBox.TabStop = false;
            this.die4PictureBox.Visible = false;
            // 
            // die5PictureBox
            // 
            this.die5PictureBox.Image = ((System.Drawing.Image)(resources.GetObject("die5PictureBox.Image")));
            this.die5PictureBox.Location = new System.Drawing.Point(12, 10);
            this.die5PictureBox.Name = "die5PictureBox";
            this.die5PictureBox.Size = new System.Drawing.Size(103, 104);
            this.die5PictureBox.TabIndex = 4;
            this.die5PictureBox.TabStop = false;
            this.die5PictureBox.Visible = false;
            // 
            // die6PictureBox
            // 
            this.die6PictureBox.Image = ((System.Drawing.Image)(resources.GetObject("die6PictureBox.Image")));
            this.die6PictureBox.Location = new System.Drawing.Point(12, 10);
            this.die6PictureBox.Name = "die6PictureBox";
            this.die6PictureBox.Size = new System.Drawing.Size(104, 103);
            this.die6PictureBox.TabIndex = 5;
            this.die6PictureBox.TabStop = false;
            this.die6PictureBox.Visible = false;
            this.die6PictureBox.WaitOnLoad = true;
            // 
            // die6PictureBox2
            // 
            this.die6PictureBox2.Image = ((System.Drawing.Image)(resources.GetObject("die6PictureBox2.Image")));
            this.die6PictureBox2.Location = new System.Drawing.Point(122, 10);
            this.die6PictureBox2.Name = "die6PictureBox2";
            this.die6PictureBox2.Size = new System.Drawing.Size(104, 105);
            this.die6PictureBox2.TabIndex = 11;
            this.die6PictureBox2.TabStop = false;
            this.die6PictureBox2.Visible = false;
            // 
            // die5PictureBox2
            // 
            this.die5PictureBox2.Image = ((System.Drawing.Image)(resources.GetObject("die5PictureBox2.Image")));
            this.die5PictureBox2.Location = new System.Drawing.Point(122, 10);
            this.die5PictureBox2.Name = "die5PictureBox2";
            this.die5PictureBox2.Size = new System.Drawing.Size(104, 104);
            this.die5PictureBox2.TabIndex = 10;
            this.die5PictureBox2.TabStop = false;
            this.die5PictureBox2.Visible = false;
            // 
            // die4PictureBox2
            // 
            this.die4PictureBox2.Image = ((System.Drawing.Image)(resources.GetObject("die4PictureBox2.Image")));
            this.die4PictureBox2.Location = new System.Drawing.Point(122, 10);
            this.die4PictureBox2.Name = "die4PictureBox2";
            this.die4PictureBox2.Size = new System.Drawing.Size(104, 104);
            this.die4PictureBox2.TabIndex = 9;
            this.die4PictureBox2.TabStop = false;
            this.die4PictureBox2.Visible = false;
            // 
            // die3PictureBox2
            // 
            this.die3PictureBox2.Image = ((System.Drawing.Image)(resources.GetObject("die3PictureBox2.Image")));
            this.die3PictureBox2.Location = new System.Drawing.Point(122, 10);
            this.die3PictureBox2.Name = "die3PictureBox2";
            this.die3PictureBox2.Size = new System.Drawing.Size(104, 105);
            this.die3PictureBox2.TabIndex = 8;
            this.die3PictureBox2.TabStop = false;
            this.die3PictureBox2.Visible = false;
            // 
            // die2PictureBox2
            // 
            this.die2PictureBox2.Image = ((System.Drawing.Image)(resources.GetObject("die2PictureBox2.Image")));
            this.die2PictureBox2.Location = new System.Drawing.Point(122, 10);
            this.die2PictureBox2.Name = "die2PictureBox2";
            this.die2PictureBox2.Size = new System.Drawing.Size(105, 104);
            this.die2PictureBox2.TabIndex = 7;
            this.die2PictureBox2.TabStop = false;
            this.die2PictureBox2.Visible = false;
            // 
            // die1PictureBox2
            // 
            this.die1PictureBox2.Image = ((System.Drawing.Image)(resources.GetObject("die1PictureBox2.Image")));
            this.die1PictureBox2.Location = new System.Drawing.Point(122, 10);
            this.die1PictureBox2.Name = "die1PictureBox2";
            this.die1PictureBox2.Size = new System.Drawing.Size(104, 104);
            this.die1PictureBox2.TabIndex = 6;
            this.die1PictureBox2.TabStop = false;
            this.die1PictureBox2.Visible = false;
            // 
            // rollButton
            // 
            this.rollButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rollButton.Location = new System.Drawing.Point(75, 132);
            this.rollButton.Name = "rollButton";
            this.rollButton.Size = new System.Drawing.Size(75, 28);
            this.rollButton.TabIndex = 12;
            this.rollButton.Text = "ROLL!";
            this.rollButton.UseVisualStyleBackColor = true;
            this.rollButton.Click += new System.EventHandler(this.rollButton_Click);
            // 
            // exitButton
            // 
            this.exitButton.Location = new System.Drawing.Point(75, 166);
            this.exitButton.Name = "exitButton";
            this.exitButton.Size = new System.Drawing.Size(75, 23);
            this.exitButton.TabIndex = 13;
            this.exitButton.Text = "Exit";
            this.exitButton.UseVisualStyleBackColor = true;
            this.exitButton.Click += new System.EventHandler(this.exitButton_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(238, 200);
            this.Controls.Add(this.exitButton);
            this.Controls.Add(this.rollButton);
            this.Controls.Add(this.die6PictureBox2);
            this.Controls.Add(this.die5PictureBox2);
            this.Controls.Add(this.die4PictureBox2);
            this.Controls.Add(this.die3PictureBox2);
            this.Controls.Add(this.die2PictureBox2);
            this.Controls.Add(this.die1PictureBox2);
            this.Controls.Add(this.die6PictureBox);
            this.Controls.Add(this.die5PictureBox);
            this.Controls.Add(this.die4PictureBox);
            this.Controls.Add(this.die3PictureBox);
            this.Controls.Add(this.die2PictureBox);
            this.Controls.Add(this.die1PictureBox);
            this.Name = "Form1";
            this.Text = "Form1";
            ((System.ComponentModel.ISupportInitialize)(this.die1PictureBox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.die2PictureBox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.die3PictureBox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.die4PictureBox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.die5PictureBox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.die6PictureBox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.die6PictureBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.die5PictureBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.die4PictureBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.die3PictureBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.die2PictureBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.die1PictureBox2)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.PictureBox die1PictureBox;
        private System.Windows.Forms.PictureBox die2PictureBox;
        private System.Windows.Forms.PictureBox die3PictureBox;
        private System.Windows.Forms.PictureBox die4PictureBox;
        private System.Windows.Forms.PictureBox die5PictureBox;
        private System.Windows.Forms.PictureBox die6PictureBox;
        private System.Windows.Forms.PictureBox die6PictureBox2;
        private System.Windows.Forms.PictureBox die5PictureBox2;
        private System.Windows.Forms.PictureBox die4PictureBox2;
        private System.Windows.Forms.PictureBox die3PictureBox2;
        private System.Windows.Forms.PictureBox die2PictureBox2;
        private System.Windows.Forms.PictureBox die1PictureBox2;
        private System.Windows.Forms.Button rollButton;
        private System.Windows.Forms.Button exitButton;
    }
}

