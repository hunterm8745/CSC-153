﻿namespace M5HW2_Hunter
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.oilLubeGroupBox = new System.Windows.Forms.GroupBox();
            this.lubeCheckBox = new System.Windows.Forms.CheckBox();
            this.oilCheckBox = new System.Windows.Forms.CheckBox();
            this.flushesGroupBox = new System.Windows.Forms.GroupBox();
            this.transCheckBox = new System.Windows.Forms.CheckBox();
            this.radCheckBox = new System.Windows.Forms.CheckBox();
            this.miscGroupBox = new System.Windows.Forms.GroupBox();
            this.tireCheckBox = new System.Windows.Forms.CheckBox();
            this.muffCheckBox = new System.Windows.Forms.CheckBox();
            this.inspCheckBox = new System.Windows.Forms.CheckBox();
            this.partsLaborGroupBox = new System.Windows.Forms.GroupBox();
            this.laborTextBox = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.partsTextBox = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.summaryGroupBox = new System.Windows.Forms.GroupBox();
            this.feesLabel = new System.Windows.Forms.Label();
            this.taxLabel = new System.Windows.Forms.Label();
            this.partsLabel = new System.Windows.Forms.Label();
            this.laborLabel = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.calculateButton = new System.Windows.Forms.Button();
            this.clearButton = new System.Windows.Forms.Button();
            this.exitButton = new System.Windows.Forms.Button();
            this.oilLubeGroupBox.SuspendLayout();
            this.flushesGroupBox.SuspendLayout();
            this.miscGroupBox.SuspendLayout();
            this.partsLaborGroupBox.SuspendLayout();
            this.summaryGroupBox.SuspendLayout();
            this.SuspendLayout();
            // 
            // oilLubeGroupBox
            // 
            this.oilLubeGroupBox.Controls.Add(this.lubeCheckBox);
            this.oilLubeGroupBox.Controls.Add(this.oilCheckBox);
            this.oilLubeGroupBox.Location = new System.Drawing.Point(13, 13);
            this.oilLubeGroupBox.Name = "oilLubeGroupBox";
            this.oilLubeGroupBox.Size = new System.Drawing.Size(168, 70);
            this.oilLubeGroupBox.TabIndex = 0;
            this.oilLubeGroupBox.TabStop = false;
            this.oilLubeGroupBox.Text = "Oil and Lube";
            // 
            // lubeCheckBox
            // 
            this.lubeCheckBox.AutoSize = true;
            this.lubeCheckBox.Location = new System.Drawing.Point(7, 44);
            this.lubeCheckBox.Name = "lubeCheckBox";
            this.lubeCheckBox.Size = new System.Drawing.Size(112, 17);
            this.lubeCheckBox.TabIndex = 1;
            this.lubeCheckBox.Text = "Lube Job ($18.00)";
            this.lubeCheckBox.UseVisualStyleBackColor = true;
            // 
            // oilCheckBox
            // 
            this.oilCheckBox.AutoSize = true;
            this.oilCheckBox.Location = new System.Drawing.Point(7, 20);
            this.oilCheckBox.Name = "oilCheckBox";
            this.oilCheckBox.Size = new System.Drawing.Size(120, 17);
            this.oilCheckBox.TabIndex = 0;
            this.oilCheckBox.Text = "Oil Change ($26.00)";
            this.oilCheckBox.UseVisualStyleBackColor = true;
            // 
            // flushesGroupBox
            // 
            this.flushesGroupBox.Controls.Add(this.transCheckBox);
            this.flushesGroupBox.Controls.Add(this.radCheckBox);
            this.flushesGroupBox.Location = new System.Drawing.Point(187, 14);
            this.flushesGroupBox.Name = "flushesGroupBox";
            this.flushesGroupBox.Size = new System.Drawing.Size(169, 69);
            this.flushesGroupBox.TabIndex = 1;
            this.flushesGroupBox.TabStop = false;
            this.flushesGroupBox.Text = "Flushes";
            // 
            // transCheckBox
            // 
            this.transCheckBox.AutoSize = true;
            this.transCheckBox.Location = new System.Drawing.Point(7, 43);
            this.transCheckBox.Name = "transCheckBox";
            this.transCheckBox.Size = new System.Drawing.Size(157, 17);
            this.transCheckBox.TabIndex = 1;
            this.transCheckBox.Text = "Transmission Flush ($80.00)";
            this.transCheckBox.UseVisualStyleBackColor = true;
            // 
            // radCheckBox
            // 
            this.radCheckBox.AutoSize = true;
            this.radCheckBox.Location = new System.Drawing.Point(7, 19);
            this.radCheckBox.Name = "radCheckBox";
            this.radCheckBox.Size = new System.Drawing.Size(136, 17);
            this.radCheckBox.TabIndex = 0;
            this.radCheckBox.Text = "Radiator Flush ($30.00)";
            this.radCheckBox.UseVisualStyleBackColor = true;
            // 
            // miscGroupBox
            // 
            this.miscGroupBox.Controls.Add(this.tireCheckBox);
            this.miscGroupBox.Controls.Add(this.muffCheckBox);
            this.miscGroupBox.Controls.Add(this.inspCheckBox);
            this.miscGroupBox.Location = new System.Drawing.Point(13, 89);
            this.miscGroupBox.Name = "miscGroupBox";
            this.miscGroupBox.Size = new System.Drawing.Size(168, 93);
            this.miscGroupBox.TabIndex = 2;
            this.miscGroupBox.TabStop = false;
            this.miscGroupBox.Text = "Misc";
            // 
            // tireCheckBox
            // 
            this.tireCheckBox.AutoSize = true;
            this.tireCheckBox.Location = new System.Drawing.Point(7, 67);
            this.tireCheckBox.Name = "tireCheckBox";
            this.tireCheckBox.Size = new System.Drawing.Size(129, 17);
            this.tireCheckBox.TabIndex = 2;
            this.tireCheckBox.Text = "Tire Rotation ($20.00)";
            this.tireCheckBox.UseVisualStyleBackColor = true;
            // 
            // muffCheckBox
            // 
            this.muffCheckBox.AutoSize = true;
            this.muffCheckBox.Location = new System.Drawing.Point(7, 44);
            this.muffCheckBox.Name = "muffCheckBox";
            this.muffCheckBox.Size = new System.Drawing.Size(149, 17);
            this.muffCheckBox.TabIndex = 1;
            this.muffCheckBox.Text = "Replace Muffler ($100.00)";
            this.muffCheckBox.UseVisualStyleBackColor = true;
            // 
            // inspCheckBox
            // 
            this.inspCheckBox.AutoSize = true;
            this.inspCheckBox.Location = new System.Drawing.Point(7, 20);
            this.inspCheckBox.Name = "inspCheckBox";
            this.inspCheckBox.Size = new System.Drawing.Size(117, 17);
            this.inspCheckBox.TabIndex = 0;
            this.inspCheckBox.Text = "Inspection ($15.00)";
            this.inspCheckBox.UseVisualStyleBackColor = true;
            // 
            // partsLaborGroupBox
            // 
            this.partsLaborGroupBox.Controls.Add(this.laborTextBox);
            this.partsLaborGroupBox.Controls.Add(this.label2);
            this.partsLaborGroupBox.Controls.Add(this.partsTextBox);
            this.partsLaborGroupBox.Controls.Add(this.label1);
            this.partsLaborGroupBox.Location = new System.Drawing.Point(187, 89);
            this.partsLaborGroupBox.Name = "partsLaborGroupBox";
            this.partsLaborGroupBox.Size = new System.Drawing.Size(169, 92);
            this.partsLaborGroupBox.TabIndex = 3;
            this.partsLaborGroupBox.TabStop = false;
            this.partsLaborGroupBox.Text = "Parts and Labor";
            // 
            // laborTextBox
            // 
            this.laborTextBox.Location = new System.Drawing.Point(80, 54);
            this.laborTextBox.Name = "laborTextBox";
            this.laborTextBox.Size = new System.Drawing.Size(49, 20);
            this.laborTextBox.TabIndex = 3;
            this.laborTextBox.Text = "0";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(36, 57);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(46, 13);
            this.label2.TabIndex = 2;
            this.label2.Text = "Labor: $";
            // 
            // partsTextBox
            // 
            this.partsTextBox.Location = new System.Drawing.Point(80, 21);
            this.partsTextBox.Name = "partsTextBox";
            this.partsTextBox.Size = new System.Drawing.Size(49, 20);
            this.partsTextBox.TabIndex = 1;
            this.partsTextBox.Text = "0";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(39, 24);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(43, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "Parts: $";
            // 
            // summaryGroupBox
            // 
            this.summaryGroupBox.Controls.Add(this.feesLabel);
            this.summaryGroupBox.Controls.Add(this.taxLabel);
            this.summaryGroupBox.Controls.Add(this.partsLabel);
            this.summaryGroupBox.Controls.Add(this.laborLabel);
            this.summaryGroupBox.Controls.Add(this.label6);
            this.summaryGroupBox.Controls.Add(this.label5);
            this.summaryGroupBox.Controls.Add(this.label4);
            this.summaryGroupBox.Controls.Add(this.label3);
            this.summaryGroupBox.Location = new System.Drawing.Point(13, 188);
            this.summaryGroupBox.Name = "summaryGroupBox";
            this.summaryGroupBox.Size = new System.Drawing.Size(343, 143);
            this.summaryGroupBox.TabIndex = 4;
            this.summaryGroupBox.TabStop = false;
            this.summaryGroupBox.Text = "Summary";
            // 
            // feesLabel
            // 
            this.feesLabel.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.feesLabel.Location = new System.Drawing.Point(113, 105);
            this.feesLabel.Name = "feesLabel";
            this.feesLabel.Size = new System.Drawing.Size(100, 23);
            this.feesLabel.TabIndex = 7;
            this.feesLabel.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // taxLabel
            // 
            this.taxLabel.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.taxLabel.Location = new System.Drawing.Point(113, 75);
            this.taxLabel.Name = "taxLabel";
            this.taxLabel.Size = new System.Drawing.Size(100, 23);
            this.taxLabel.TabIndex = 6;
            this.taxLabel.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // partsLabel
            // 
            this.partsLabel.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.partsLabel.Location = new System.Drawing.Point(113, 45);
            this.partsLabel.Name = "partsLabel";
            this.partsLabel.Size = new System.Drawing.Size(100, 23);
            this.partsLabel.TabIndex = 5;
            this.partsLabel.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // laborLabel
            // 
            this.laborLabel.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.laborLabel.Location = new System.Drawing.Point(113, 15);
            this.laborLabel.Name = "laborLabel";
            this.laborLabel.Size = new System.Drawing.Size(100, 23);
            this.laborLabel.TabIndex = 4;
            this.laborLabel.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(44, 109);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(69, 13);
            this.label6.TabIndex = 3;
            this.label6.Text = "Total Fees: $";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(29, 79);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(84, 13);
            this.label5.TabIndex = 2;
            this.label5.Text = "Tax (on parts): $";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(70, 49);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(43, 13);
            this.label4.TabIndex = 1;
            this.label4.Text = "Parts: $";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(7, 19);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(106, 13);
            this.label3.TabIndex = 0;
            this.label3.Text = "Service and Labor: $";
            // 
            // calculateButton
            // 
            this.calculateButton.Location = new System.Drawing.Point(63, 342);
            this.calculateButton.Name = "calculateButton";
            this.calculateButton.Size = new System.Drawing.Size(75, 23);
            this.calculateButton.TabIndex = 5;
            this.calculateButton.Text = "Calculate";
            this.calculateButton.UseVisualStyleBackColor = true;
            this.calculateButton.Click += new System.EventHandler(this.calculateButton_Click);
            // 
            // clearButton
            // 
            this.clearButton.Location = new System.Drawing.Point(145, 342);
            this.clearButton.Name = "clearButton";
            this.clearButton.Size = new System.Drawing.Size(75, 23);
            this.clearButton.TabIndex = 6;
            this.clearButton.Text = "Clear";
            this.clearButton.UseVisualStyleBackColor = true;
            this.clearButton.Click += new System.EventHandler(this.clearButton_Click);
            // 
            // exitButton
            // 
            this.exitButton.Location = new System.Drawing.Point(227, 342);
            this.exitButton.Name = "exitButton";
            this.exitButton.Size = new System.Drawing.Size(75, 23);
            this.exitButton.TabIndex = 7;
            this.exitButton.Text = "Exit";
            this.exitButton.UseVisualStyleBackColor = true;
            this.exitButton.Click += new System.EventHandler(this.exitButton_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(368, 377);
            this.Controls.Add(this.exitButton);
            this.Controls.Add(this.clearButton);
            this.Controls.Add(this.calculateButton);
            this.Controls.Add(this.summaryGroupBox);
            this.Controls.Add(this.partsLaborGroupBox);
            this.Controls.Add(this.miscGroupBox);
            this.Controls.Add(this.flushesGroupBox);
            this.Controls.Add(this.oilLubeGroupBox);
            this.Name = "Form1";
            this.Text = "Form1";
            this.oilLubeGroupBox.ResumeLayout(false);
            this.oilLubeGroupBox.PerformLayout();
            this.flushesGroupBox.ResumeLayout(false);
            this.flushesGroupBox.PerformLayout();
            this.miscGroupBox.ResumeLayout(false);
            this.miscGroupBox.PerformLayout();
            this.partsLaborGroupBox.ResumeLayout(false);
            this.partsLaborGroupBox.PerformLayout();
            this.summaryGroupBox.ResumeLayout(false);
            this.summaryGroupBox.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox oilLubeGroupBox;
        private System.Windows.Forms.CheckBox lubeCheckBox;
        private System.Windows.Forms.CheckBox oilCheckBox;
        private System.Windows.Forms.GroupBox flushesGroupBox;
        private System.Windows.Forms.CheckBox transCheckBox;
        private System.Windows.Forms.CheckBox radCheckBox;
        private System.Windows.Forms.GroupBox miscGroupBox;
        private System.Windows.Forms.CheckBox tireCheckBox;
        private System.Windows.Forms.CheckBox muffCheckBox;
        private System.Windows.Forms.CheckBox inspCheckBox;
        private System.Windows.Forms.GroupBox partsLaborGroupBox;
        private System.Windows.Forms.TextBox laborTextBox;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox partsTextBox;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.GroupBox summaryGroupBox;
        private System.Windows.Forms.Label feesLabel;
        private System.Windows.Forms.Label taxLabel;
        private System.Windows.Forms.Label partsLabel;
        private System.Windows.Forms.Label laborLabel;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Button calculateButton;
        private System.Windows.Forms.Button clearButton;
        private System.Windows.Forms.Button exitButton;
    }
}

