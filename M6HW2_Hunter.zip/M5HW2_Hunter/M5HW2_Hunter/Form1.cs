﻿/**
* April 25, 2018
* CSC 153
* Matthew Hunter
* Calculate the bill at an autimotive shop
*/

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace M5HW2_Hunter
{
    public partial class Form1 : Form
    {
        double oilCost = 26;            //Hold oil cost
        double lubeCost = 18;           //Hold lube cost
        double radCost = 30;            //Hold radiator cost
        double transCost = 80;          //Hold transition cost
        double inspCost = 15;           //Hold inspection cost
        double mufflerCost = 100;       //Hold muffler cost
        double tireCost = 20;           //Hold tire cost
        double salesTax = .06;          //Hold sales tax

        public Form1()
        {
            InitializeComponent();
        }

        //Check what services are checked in oil and lube then add their cost to total
        private double OilLubeCharges(ref double oilLubeTotal)
        {
            oilLubeTotal = 0;

            if (oilCheckBox.Checked)
            {
                oilLubeTotal += oilCost;
            }

            if (lubeCheckBox.Checked)
            {
                oilLubeTotal += lubeCost;
            }

            return oilLubeTotal;
        }


        //Check what services are checked in flushes then add their cost to total
        private double FlushCharges(ref double flushTotal)
        {
            flushTotal = 0;

            if (radCheckBox.Checked)
            {
                flushTotal += radCost;
            }

            if (transCheckBox.Checked)
            {
                flushTotal += transCost;
            }

            return flushTotal;
        }


        //Check what services are checked in Misc services then add their cost to total
        private double MiscCharges(ref double miscTotal)
        {
            miscTotal = 0;

            if (inspCheckBox.Checked)
            {
                miscTotal += inspCost;
            }

            if (muffCheckBox.Checked)
            {
                miscTotal += mufflerCost;
            }

            if (tireCheckBox.Checked)
            {
                miscTotal += tireCost;
            }

            return miscTotal;
        }


        //Check that entered parts cost is valid
        private bool CheckParts(ref bool partsGood)
        {
            double parts;

            partsGood = false;

            if (double.TryParse(partsTextBox.Text, out parts))
            {
                partsGood = true;
            }
            else
            {
                MessageBox.Show("Parts Cost is Invalid.");
            }

            return partsGood;
        }


        //Check that entered labor cost is valid
        private bool CheckLabor(ref bool laborGood)
        {
            double labor;

            laborGood = false;

            if (double.TryParse(laborTextBox.Text, out labor))
            {
                laborGood = true;
            }
            else
            {
                MessageBox.Show("Labor Cost is Invalid.");
            }

            return laborGood;
        }

        //Calculate total of parts and labor
        private double OtherCharges(ref double otherTotal)
        {
            bool inputGood = false;

            otherTotal = 0;

            if (CheckParts(ref inputGood))
            {
                otherTotal += double.Parse(partsTextBox.Text);
            }

            if (CheckLabor(ref inputGood))
            {
                otherTotal += double.Parse(laborTextBox.Text);
            }

            return otherTotal;
        }


        //Calculate tax on parts
        private double TaxCharges(ref double partsTax)
        {
            bool inputGood = false;

            partsTax = 0;

            if (CheckParts(ref inputGood))
            {
                partsTax += double.Parse(partsTextBox.Text) * salesTax;
            }

            return partsTax;
        }

        //Calculate the total cost of all selected services and parts
        private double TotalCharges(ref double total)
        {
            double oilLubeTotal = 0;
            double flushTotal = 0;
            double miscTotal = 0;
            double otherTotal = 0;
            double partsTax = 0;

            total = OilLubeCharges(ref oilLubeTotal) + FlushCharges(ref flushTotal) + MiscCharges(ref miscTotal) + OtherCharges(ref otherTotal) + TaxCharges(ref partsTax);

            return total;
        }

        //Clear all boxes in oil and lube
        private void ClearOilLube()
        {
            oilCheckBox.Checked = false;
            lubeCheckBox.Checked = false;
        }

        //Clear all boxes in flushes
        private void ClearFlushes()
        {
            radCheckBox.Checked = false;
            transCheckBox.Checked = false;
        }

        //Clear all boxes Misc
        private void ClearMisc()
        {
            inspCheckBox.Checked = false;
            muffCheckBox.Checked = false;
            tireCheckBox.Checked = false;
        }

        //Clear Parts and Labor
        private void ClearOther()
        {
            partsTextBox.Text = "0";
            laborTextBox.Text = "0";
        }

        //Clear all displayed values
        private void ClearFees()
        {
            laborLabel.Text = "";
            partsLabel.Text = "";
            taxLabel.Text = "";
            feesLabel.Text = "";
        }

        private void calculateButton_Click(object sender, EventArgs e)
        {
            double total = 0;           //Hold total cost
            double laborService = 0;    //Hold labor and services cost
            double partsTax = 0;        //Hold tax on parts
            double oilLubeTotal = 0;    //Hold cost of oil and/or lube
            double flushTotal = 0;      //Hold any flush costs
            double miscTotal = 0;       //Hold and misc total
            bool inputGood = false;     //Hold whether user input is valid

            //Check if user input in parts is valid
            if (CheckParts(ref inputGood))
            {
                //Check if user input in labor is valid
                if (CheckLabor(ref inputGood))
                {
                    //Call TotalCharges
                    TotalCharges(ref total);

                    //Display what was returned from total charges
                    feesLabel.Text = total.ToString();

                    //Calculate total services without parts or tax
                    laborService = double.Parse(laborTextBox.Text) + OilLubeCharges(ref oilLubeTotal) + FlushCharges(ref flushTotal) + MiscCharges(ref miscTotal);

                    //Display returned value in laborService
                    laborLabel.Text = laborService.ToString();

                    //Call TaxCharges
                    TaxCharges(ref partsTax);

                    //Display returned values from TaxCharges
                    taxLabel.Text = partsTax.ToString();

                    //Display user input from parts box
                    partsLabel.Text = partsTextBox.Text;
                }
            }
        }

        private void clearButton_Click(object sender, EventArgs e)
        {
            ClearOilLube();
            ClearFlushes();
            ClearMisc();
            ClearOther();
            ClearFees();
        }

        private void exitButton_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
