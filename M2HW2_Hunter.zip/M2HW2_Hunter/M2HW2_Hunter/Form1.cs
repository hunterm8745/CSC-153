﻿/**
* Febuary 14, 2018
* CSC 153
* Matthew Hunter
* Create a scentence using given words
*/

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace M2HW2_Hunter
{
    public partial class Form1 : Form
    {
        public String input;     //Hold Input
        public Form1()
        {
            InitializeComponent();
        }

        private void captialAButton_Click(object sender, EventArgs e)
        {
            try
            {
                //Assign button text to input
                input = capitalAButton.Text;

                //add button text to scentenceLabel
                scentenceLabel.Text += input;
            }
            catch (Exception ex)
            {
                //Display default error message
                MessageBox.Show(ex.Message);
            }
        }

        private void lowerAButton_Click(object sender, EventArgs e)
        {
            try
            {
                //Assign button text to input
                input = lowerAButton.Text;

                //add button text to scentenceLabel
                scentenceLabel.Text += input;
            }
            catch (Exception ex)
            {
                //Display default error message
                MessageBox.Show(ex.Message);
            }
        }

        private void capitilizedAnButton_Click(object sender, EventArgs e)
        {
            try
            {
                //Assign button text to input
                input = capitalAnButton.Text;

                //add button text to scentenceLabel
                scentenceLabel.Text += input;
            }
            catch (Exception ex)
            {
                //Display default error message
                MessageBox.Show(ex.Message);
            }
        }

        private void lowercaseAnButton_Click(object sender, EventArgs e)
        {
            try
            {
                //Assign button text to input
                input = lowercaseAnButton.Text;

                //add button text to scentenceLabel
                scentenceLabel.Text += input;
            }
            catch (Exception ex)
            {
                //Display default error message
                MessageBox.Show(ex.Message);
            }
        }

        private void capitalTheButton_Click(object sender, EventArgs e)
        {
            try
            {
                //Assign button text to input
                input = capitalTheButton.Text;

                //add button text to scentenceLabel
                scentenceLabel.Text += input;
            }
            catch (Exception ex)
            {
                //Display default error message
                MessageBox.Show(ex.Message);
            }
        }

        private void lowercaseTheButton_Click(object sender, EventArgs e)
        {
            try
            {
                //Assign button text to input
                input = lowercaseTheButton.Text;

                //add button text to scentenceLabel
                scentenceLabel.Text += input;
            }
            catch (Exception ex)
            {
                //Display default error message
                MessageBox.Show(ex.Message);
            }
        }

        private void manButton_Click(object sender, EventArgs e)
        {
            try
            {
                //Assign button text to input
                input = manButton.Text;

                //add button text to scentenceLabel
                scentenceLabel.Text += input;
            }
            catch (Exception ex)
            {
                //Display default error message
                MessageBox.Show(ex.Message);
            }
        }

        private void womanButton_Click(object sender, EventArgs e)
        {
            try
            {
                //Assign button text to input
                input = womanButton.Text;

                //add button text to scentenceLabel
                scentenceLabel.Text += input;
            }
            catch (Exception ex)
            {
                //Display default error message
                MessageBox.Show(ex.Message);
            }
        }

        private void dogButton_Click(object sender, EventArgs e)
        {
            try
            {
                //Assign button text to input
                input = dogButton.Text;

                //add button text to scentenceLabel
                scentenceLabel.Text += input;
            }
            catch (Exception ex)
            {
                //Display default error message
                MessageBox.Show(ex.Message);
            }
        }

        private void catButton_Click(object sender, EventArgs e)
        {
            try
            {
                //Assign button text to input
                input = catButton.Text;

                //add button text to scentenceLabel
                scentenceLabel.Text += input;
            }
            catch (Exception ex)
            {
                //Display default error message
                MessageBox.Show(ex.Message);
            }
        }

        private void carButton_Click(object sender, EventArgs e)
        {
            try
            {
                //Assign button text to input
                input = carButton.Text;

                //add button text to scentenceLabel
                scentenceLabel.Text += input;
            }
            catch (Exception ex)
            {
                //Display default error message
                MessageBox.Show(ex.Message);
            }
        }

        private void bicycleButton_Click(object sender, EventArgs e)
        {
            try
            {
                //Assign button text to input
                input = bicycleButton.Text;

                //add button text to scentenceLabel
                scentenceLabel.Text += input;
            }
            catch (Exception ex)
            {
                //Display default error message
                MessageBox.Show(ex.Message);
            }
        }

        private void beautifulButton_Click(object sender, EventArgs e)
        {
            try
            {
                //Assign button text to input
                input = beautifulButton.Text;

                //add button text to scentenceLabel
                scentenceLabel.Text += input;
            }
            catch (Exception ex)
            {
                //Display default error message
                MessageBox.Show(ex.Message);
            }
        }

        private void bigButton_Click(object sender, EventArgs e)
        {
            try
            {
                //Assign button text to input
                input = bigButton.Text;

                //add button text to scentenceLabel
                scentenceLabel.Text += input;
            }
            catch (Exception ex)
            {
                //Display default error message
                MessageBox.Show(ex.Message);
            }
        }

        private void smallButton_Click(object sender, EventArgs e)
        {
            try
            {
                //Assign button text to input
                input = smallButton.Text;

                //add button text to scentenceLabel
                scentenceLabel.Text += input;
            }
            catch (Exception ex)
            {
                //Display default error message
                MessageBox.Show(ex.Message);
            }
        }

        private void strangeButton_Click(object sender, EventArgs e)
        {
            try
            {
                //Assign button text to input
                input = strangeButton.Text;

                //add button text to scentenceLabel
                scentenceLabel.Text += input;
            }
            catch (Exception ex)
            {
                //Display default error message
                MessageBox.Show(ex.Message);
            }
        }

        private void lookedAtButton_Click(object sender, EventArgs e)
        {
            try
            {
                //Assign button text to input
                input = lookedAtButton.Text;

                //add button text to scentenceLabel
                scentenceLabel.Text += input;
            }
            catch (Exception ex)
            {
                //Display default error message
                MessageBox.Show(ex.Message);
            }
        }

        private void rodeButton_Click(object sender, EventArgs e)
        {
            try
            {
                //Assign button text to input
                input = rodeButton.Text;

                //add button text to scentenceLabel
                scentenceLabel.Text += input;
            }
            catch (Exception ex)
            {
                //Display default error message
                MessageBox.Show(ex.Message);
            }
        }

        private void spokeToButton_Click(object sender, EventArgs e)
        {
            try
            {
                //Assign button text to input
                input = spokeToButton.Text;

                //add button text to scentenceLabel
                scentenceLabel.Text += input;
            }
            catch (Exception ex)
            {
                //Display default error message
                MessageBox.Show(ex.Message);
            }
        }

        private void laughedAtButton_Click(object sender, EventArgs e)
        {
            try
            {
                //Assign button text to input
                input = laughedAtButton.Text;

                //add button text to scentenceLabel
                scentenceLabel.Text += input;
            }
            catch (Exception ex)
            {
                //Display default error message
                MessageBox.Show(ex.Message);
            }
        }

        private void droveButton_Click(object sender, EventArgs e)
        {
            try
            {
                //Assign button text to input
                input = droveButton.Text;

                //add button text to scentenceLabel
                scentenceLabel.Text += input;
            }
            catch (Exception ex)
            {
                //Display default error message
                MessageBox.Show(ex.Message);
            }
        }

        private void spaceButton_Click(object sender, EventArgs e)
        {
            try
            {
                //Assign button text to input
                input = " ";

                //add button text to scentenceLabel
                scentenceLabel.Text += input;
            }
            catch (Exception ex)
            {
                //Display default error message
                MessageBox.Show(ex.Message);
            }
        }

        private void periodButton_Click(object sender, EventArgs e)
        {
            try
            {
                //Assign button text to input
                input = periodButton.Text;

                //add button text to scentenceLabel
                scentenceLabel.Text += input;
            }
            catch (Exception ex)
            {
                //Display default error message
                MessageBox.Show(ex.Message);
            }
        }

        private void exclamationPointButton_Click(object sender, EventArgs e)
        {
            try
            {
                //Assign button text to input
                input = exclamationButton.Text;

                //add button text to scentenceLabel
                scentenceLabel.Text += input;
            }
            catch (Exception ex)
            {
                //Display default error message
                MessageBox.Show(ex.Message);
            }
        }

        private void clearButton_Click(object sender, EventArgs e)
        {
            //Set the label to nothing
            scentenceLabel.Text = "";
        }

        private void exitButton_Click(object sender, EventArgs e)
        {
            //Close the program
            this.Close();
        }
    }
}
