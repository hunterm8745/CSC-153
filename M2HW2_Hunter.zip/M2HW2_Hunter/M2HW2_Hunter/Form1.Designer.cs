﻿namespace M2HW2_Hunter
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.capitalAButton = new System.Windows.Forms.Button();
            this.lowerAButton = new System.Windows.Forms.Button();
            this.capitalAnButton = new System.Windows.Forms.Button();
            this.lowercaseAnButton = new System.Windows.Forms.Button();
            this.capitalTheButton = new System.Windows.Forms.Button();
            this.lowercaseTheButton = new System.Windows.Forms.Button();
            this.manButton = new System.Windows.Forms.Button();
            this.womanButton = new System.Windows.Forms.Button();
            this.dogButton = new System.Windows.Forms.Button();
            this.carButton = new System.Windows.Forms.Button();
            this.bicycleButton = new System.Windows.Forms.Button();
            this.beautifulButton = new System.Windows.Forms.Button();
            this.bigButton = new System.Windows.Forms.Button();
            this.smallButton = new System.Windows.Forms.Button();
            this.strangeButton = new System.Windows.Forms.Button();
            this.lookedAtButton = new System.Windows.Forms.Button();
            this.rodeButton = new System.Windows.Forms.Button();
            this.spokeToButton = new System.Windows.Forms.Button();
            this.laughedAtButton = new System.Windows.Forms.Button();
            this.droveButton = new System.Windows.Forms.Button();
            this.spaceButton = new System.Windows.Forms.Button();
            this.periodButton = new System.Windows.Forms.Button();
            this.exclamationButton = new System.Windows.Forms.Button();
            this.scentenceLabel = new System.Windows.Forms.Label();
            this.catButton = new System.Windows.Forms.Button();
            this.clearButton = new System.Windows.Forms.Button();
            this.exitButton = new System.Windows.Forms.Button();
            this.instructonLabel = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // capitalAButton
            // 
            this.capitalAButton.Location = new System.Drawing.Point(151, 51);
            this.capitalAButton.Name = "capitalAButton";
            this.capitalAButton.Size = new System.Drawing.Size(44, 23);
            this.capitalAButton.TabIndex = 0;
            this.capitalAButton.Text = "A";
            this.capitalAButton.UseVisualStyleBackColor = true;
            this.capitalAButton.Click += new System.EventHandler(this.captialAButton_Click);
            // 
            // lowerAButton
            // 
            this.lowerAButton.Location = new System.Drawing.Point(201, 50);
            this.lowerAButton.Name = "lowerAButton";
            this.lowerAButton.Size = new System.Drawing.Size(44, 23);
            this.lowerAButton.TabIndex = 1;
            this.lowerAButton.Text = "a";
            this.lowerAButton.UseVisualStyleBackColor = true;
            this.lowerAButton.Click += new System.EventHandler(this.lowerAButton_Click);
            // 
            // capitalAnButton
            // 
            this.capitalAnButton.Location = new System.Drawing.Point(251, 51);
            this.capitalAnButton.Name = "capitalAnButton";
            this.capitalAnButton.Size = new System.Drawing.Size(44, 23);
            this.capitalAnButton.TabIndex = 2;
            this.capitalAnButton.Text = "An";
            this.capitalAnButton.UseVisualStyleBackColor = true;
            this.capitalAnButton.Click += new System.EventHandler(this.capitilizedAnButton_Click);
            // 
            // lowercaseAnButton
            // 
            this.lowercaseAnButton.Location = new System.Drawing.Point(301, 52);
            this.lowercaseAnButton.Name = "lowercaseAnButton";
            this.lowercaseAnButton.Size = new System.Drawing.Size(44, 23);
            this.lowercaseAnButton.TabIndex = 3;
            this.lowercaseAnButton.Text = "an";
            this.lowercaseAnButton.UseVisualStyleBackColor = true;
            this.lowercaseAnButton.Click += new System.EventHandler(this.lowercaseAnButton_Click);
            // 
            // capitalTheButton
            // 
            this.capitalTheButton.Location = new System.Drawing.Point(351, 51);
            this.capitalTheButton.Name = "capitalTheButton";
            this.capitalTheButton.Size = new System.Drawing.Size(44, 23);
            this.capitalTheButton.TabIndex = 4;
            this.capitalTheButton.Text = "The";
            this.capitalTheButton.UseVisualStyleBackColor = true;
            this.capitalTheButton.Click += new System.EventHandler(this.capitalTheButton_Click);
            // 
            // lowercaseTheButton
            // 
            this.lowercaseTheButton.Location = new System.Drawing.Point(401, 51);
            this.lowercaseTheButton.Name = "lowercaseTheButton";
            this.lowercaseTheButton.Size = new System.Drawing.Size(43, 22);
            this.lowercaseTheButton.TabIndex = 5;
            this.lowercaseTheButton.Text = "the";
            this.lowercaseTheButton.UseVisualStyleBackColor = true;
            this.lowercaseTheButton.Click += new System.EventHandler(this.lowercaseTheButton_Click);
            // 
            // manButton
            // 
            this.manButton.Location = new System.Drawing.Point(134, 83);
            this.manButton.Name = "manButton";
            this.manButton.Size = new System.Drawing.Size(43, 23);
            this.manButton.TabIndex = 6;
            this.manButton.Text = "man";
            this.manButton.UseVisualStyleBackColor = true;
            this.manButton.Click += new System.EventHandler(this.manButton_Click);
            // 
            // womanButton
            // 
            this.womanButton.Location = new System.Drawing.Point(182, 83);
            this.womanButton.Name = "womanButton";
            this.womanButton.Size = new System.Drawing.Size(55, 23);
            this.womanButton.TabIndex = 7;
            this.womanButton.Text = "woman";
            this.womanButton.UseVisualStyleBackColor = true;
            this.womanButton.Click += new System.EventHandler(this.womanButton_Click);
            // 
            // dogButton
            // 
            this.dogButton.Location = new System.Drawing.Point(242, 83);
            this.dogButton.Name = "dogButton";
            this.dogButton.Size = new System.Drawing.Size(43, 25);
            this.dogButton.TabIndex = 8;
            this.dogButton.Text = "dog";
            this.dogButton.UseVisualStyleBackColor = true;
            this.dogButton.Click += new System.EventHandler(this.dogButton_Click);
            // 
            // carButton
            // 
            this.carButton.Location = new System.Drawing.Point(340, 82);
            this.carButton.Name = "carButton";
            this.carButton.Size = new System.Drawing.Size(44, 24);
            this.carButton.TabIndex = 9;
            this.carButton.Text = "car";
            this.carButton.UseVisualStyleBackColor = true;
            this.carButton.Click += new System.EventHandler(this.carButton_Click);
            // 
            // bicycleButton
            // 
            this.bicycleButton.Location = new System.Drawing.Point(390, 82);
            this.bicycleButton.Name = "bicycleButton";
            this.bicycleButton.Size = new System.Drawing.Size(74, 23);
            this.bicycleButton.TabIndex = 10;
            this.bicycleButton.Text = "bicycle";
            this.bicycleButton.UseVisualStyleBackColor = true;
            this.bicycleButton.Click += new System.EventHandler(this.bicycleButton_Click);
            // 
            // beautifulButton
            // 
            this.beautifulButton.Location = new System.Drawing.Point(161, 114);
            this.beautifulButton.Name = "beautifulButton";
            this.beautifulButton.Size = new System.Drawing.Size(75, 23);
            this.beautifulButton.TabIndex = 11;
            this.beautifulButton.Text = "beautiful";
            this.beautifulButton.UseVisualStyleBackColor = true;
            this.beautifulButton.Click += new System.EventHandler(this.beautifulButton_Click);
            // 
            // bigButton
            // 
            this.bigButton.Location = new System.Drawing.Point(242, 114);
            this.bigButton.Name = "bigButton";
            this.bigButton.Size = new System.Drawing.Size(44, 23);
            this.bigButton.TabIndex = 12;
            this.bigButton.Text = "big";
            this.bigButton.UseVisualStyleBackColor = true;
            this.bigButton.Click += new System.EventHandler(this.bigButton_Click);
            // 
            // smallButton
            // 
            this.smallButton.Location = new System.Drawing.Point(292, 114);
            this.smallButton.Name = "smallButton";
            this.smallButton.Size = new System.Drawing.Size(52, 23);
            this.smallButton.TabIndex = 13;
            this.smallButton.Text = "small";
            this.smallButton.UseVisualStyleBackColor = true;
            this.smallButton.Click += new System.EventHandler(this.smallButton_Click);
            // 
            // strangeButton
            // 
            this.strangeButton.Location = new System.Drawing.Point(350, 114);
            this.strangeButton.Name = "strangeButton";
            this.strangeButton.Size = new System.Drawing.Size(75, 23);
            this.strangeButton.TabIndex = 14;
            this.strangeButton.Text = "strange";
            this.strangeButton.UseVisualStyleBackColor = true;
            this.strangeButton.Click += new System.EventHandler(this.strangeButton_Click);
            // 
            // lookedAtButton
            // 
            this.lookedAtButton.Location = new System.Drawing.Point(120, 143);
            this.lookedAtButton.Name = "lookedAtButton";
            this.lookedAtButton.Size = new System.Drawing.Size(75, 23);
            this.lookedAtButton.TabIndex = 15;
            this.lookedAtButton.Text = "looked at";
            this.lookedAtButton.UseVisualStyleBackColor = true;
            this.lookedAtButton.Click += new System.EventHandler(this.lookedAtButton_Click);
            // 
            // rodeButton
            // 
            this.rodeButton.Location = new System.Drawing.Point(201, 143);
            this.rodeButton.Name = "rodeButton";
            this.rodeButton.Size = new System.Drawing.Size(56, 23);
            this.rodeButton.TabIndex = 16;
            this.rodeButton.Text = "rode";
            this.rodeButton.UseVisualStyleBackColor = true;
            this.rodeButton.Click += new System.EventHandler(this.rodeButton_Click);
            // 
            // spokeToButton
            // 
            this.spokeToButton.Location = new System.Drawing.Point(263, 143);
            this.spokeToButton.Name = "spokeToButton";
            this.spokeToButton.Size = new System.Drawing.Size(75, 23);
            this.spokeToButton.TabIndex = 17;
            this.spokeToButton.Text = "spoke to";
            this.spokeToButton.UseVisualStyleBackColor = true;
            this.spokeToButton.Click += new System.EventHandler(this.spokeToButton_Click);
            // 
            // laughedAtButton
            // 
            this.laughedAtButton.Location = new System.Drawing.Point(344, 143);
            this.laughedAtButton.Name = "laughedAtButton";
            this.laughedAtButton.Size = new System.Drawing.Size(75, 23);
            this.laughedAtButton.TabIndex = 18;
            this.laughedAtButton.Text = "laughed at";
            this.laughedAtButton.UseVisualStyleBackColor = true;
            this.laughedAtButton.Click += new System.EventHandler(this.laughedAtButton_Click);
            // 
            // droveButton
            // 
            this.droveButton.Location = new System.Drawing.Point(425, 143);
            this.droveButton.Name = "droveButton";
            this.droveButton.Size = new System.Drawing.Size(61, 23);
            this.droveButton.TabIndex = 19;
            this.droveButton.Text = "drove";
            this.droveButton.UseVisualStyleBackColor = true;
            this.droveButton.Click += new System.EventHandler(this.droveButton_Click);
            // 
            // spaceButton
            // 
            this.spaceButton.Location = new System.Drawing.Point(220, 172);
            this.spaceButton.Name = "spaceButton";
            this.spaceButton.Size = new System.Drawing.Size(75, 23);
            this.spaceButton.TabIndex = 20;
            this.spaceButton.Text = "(Space)";
            this.spaceButton.UseVisualStyleBackColor = true;
            this.spaceButton.Click += new System.EventHandler(this.spaceButton_Click);
            // 
            // periodButton
            // 
            this.periodButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.periodButton.Location = new System.Drawing.Point(301, 172);
            this.periodButton.Name = "periodButton";
            this.periodButton.Size = new System.Drawing.Size(29, 23);
            this.periodButton.TabIndex = 21;
            this.periodButton.Text = ".";
            this.periodButton.UseVisualStyleBackColor = true;
            this.periodButton.Click += new System.EventHandler(this.periodButton_Click);
            // 
            // exclamationButton
            // 
            this.exclamationButton.Location = new System.Drawing.Point(336, 172);
            this.exclamationButton.Name = "exclamationButton";
            this.exclamationButton.Size = new System.Drawing.Size(29, 23);
            this.exclamationButton.TabIndex = 22;
            this.exclamationButton.Text = "!";
            this.exclamationButton.UseVisualStyleBackColor = true;
            this.exclamationButton.Click += new System.EventHandler(this.exclamationPointButton_Click);
            // 
            // scentenceLabel
            // 
            this.scentenceLabel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.scentenceLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.scentenceLabel.Location = new System.Drawing.Point(12, 213);
            this.scentenceLabel.Name = "scentenceLabel";
            this.scentenceLabel.Size = new System.Drawing.Size(572, 54);
            this.scentenceLabel.TabIndex = 23;
            this.scentenceLabel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // catButton
            // 
            this.catButton.Location = new System.Drawing.Point(291, 83);
            this.catButton.Name = "catButton";
            this.catButton.Size = new System.Drawing.Size(43, 23);
            this.catButton.TabIndex = 24;
            this.catButton.Text = "cat";
            this.catButton.UseVisualStyleBackColor = true;
            this.catButton.Click += new System.EventHandler(this.catButton_Click);
            // 
            // clearButton
            // 
            this.clearButton.Location = new System.Drawing.Point(220, 281);
            this.clearButton.Name = "clearButton";
            this.clearButton.Size = new System.Drawing.Size(75, 23);
            this.clearButton.TabIndex = 25;
            this.clearButton.Text = "Clear";
            this.clearButton.UseVisualStyleBackColor = true;
            this.clearButton.Click += new System.EventHandler(this.clearButton_Click);
            // 
            // exitButton
            // 
            this.exitButton.Location = new System.Drawing.Point(301, 281);
            this.exitButton.Name = "exitButton";
            this.exitButton.Size = new System.Drawing.Size(75, 23);
            this.exitButton.TabIndex = 26;
            this.exitButton.Text = "Exit";
            this.exitButton.UseVisualStyleBackColor = true;
            this.exitButton.Click += new System.EventHandler(this.exitButton_Click);
            // 
            // instructonLabel
            // 
            this.instructonLabel.AutoSize = true;
            this.instructonLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.instructonLabel.Location = new System.Drawing.Point(131, 9);
            this.instructonLabel.Name = "instructonLabel";
            this.instructonLabel.Size = new System.Drawing.Size(318, 18);
            this.instructonLabel.TabIndex = 27;
            this.instructonLabel.Text = "Click the buttons below to create a scenctence!";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(596, 316);
            this.Controls.Add(this.instructonLabel);
            this.Controls.Add(this.exitButton);
            this.Controls.Add(this.clearButton);
            this.Controls.Add(this.catButton);
            this.Controls.Add(this.scentenceLabel);
            this.Controls.Add(this.exclamationButton);
            this.Controls.Add(this.periodButton);
            this.Controls.Add(this.spaceButton);
            this.Controls.Add(this.droveButton);
            this.Controls.Add(this.laughedAtButton);
            this.Controls.Add(this.spokeToButton);
            this.Controls.Add(this.rodeButton);
            this.Controls.Add(this.lookedAtButton);
            this.Controls.Add(this.strangeButton);
            this.Controls.Add(this.smallButton);
            this.Controls.Add(this.bigButton);
            this.Controls.Add(this.beautifulButton);
            this.Controls.Add(this.bicycleButton);
            this.Controls.Add(this.carButton);
            this.Controls.Add(this.dogButton);
            this.Controls.Add(this.womanButton);
            this.Controls.Add(this.manButton);
            this.Controls.Add(this.lowercaseTheButton);
            this.Controls.Add(this.capitalTheButton);
            this.Controls.Add(this.lowercaseAnButton);
            this.Controls.Add(this.capitalAnButton);
            this.Controls.Add(this.lowerAButton);
            this.Controls.Add(this.capitalAButton);
            this.Name = "Form1";
            this.Text = "Scentence Builder";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button capitalAButton;
        private System.Windows.Forms.Button lowerAButton;
        private System.Windows.Forms.Button capitalAnButton;
        private System.Windows.Forms.Button lowercaseAnButton;
        private System.Windows.Forms.Button capitalTheButton;
        private System.Windows.Forms.Button lowercaseTheButton;
        private System.Windows.Forms.Button manButton;
        private System.Windows.Forms.Button womanButton;
        private System.Windows.Forms.Button dogButton;
        private System.Windows.Forms.Button carButton;
        private System.Windows.Forms.Button bicycleButton;
        private System.Windows.Forms.Button beautifulButton;
        private System.Windows.Forms.Button bigButton;
        private System.Windows.Forms.Button smallButton;
        private System.Windows.Forms.Button strangeButton;
        private System.Windows.Forms.Button lookedAtButton;
        private System.Windows.Forms.Button rodeButton;
        private System.Windows.Forms.Button spokeToButton;
        private System.Windows.Forms.Button laughedAtButton;
        private System.Windows.Forms.Button droveButton;
        private System.Windows.Forms.Button spaceButton;
        private System.Windows.Forms.Button periodButton;
        private System.Windows.Forms.Button exclamationButton;
        private System.Windows.Forms.Label scentenceLabel;
        private System.Windows.Forms.Button catButton;
        private System.Windows.Forms.Button clearButton;
        private System.Windows.Forms.Button exitButton;
        private System.Windows.Forms.Label instructonLabel;
    }
}

