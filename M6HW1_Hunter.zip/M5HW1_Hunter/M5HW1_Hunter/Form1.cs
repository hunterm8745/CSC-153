﻿/**
* April 11, 2018
* CSC 153
* Matthew Hunter
* Calculate meters fallen using input fall time
*/

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace M5HW1_Hunter
{
    public partial class Form1 : Form
    {
        private const double G = 9.8;
        public Form1()
        {
            InitializeComponent();
        }

        //FallingDistance method calculates and returnes distance
        private double FallingDistance (double t)
        {
            double distance = 0.5 * G * Math.Pow(t, 2);
            return distance;
        }

        private void calculateButton_Click(object sender, EventArgs e)
        {
            double t;       //Hold converted time

            //Test if time entered is valid
            if (double.TryParse(timeTextBox.Text, out t))
            {
                //use FallingDistance to get distance
                double d = FallingDistance(t);

                //Display Distance
                distanceLabel.Text = d.ToString("n") + " meters";
            }
            else
            {
                //Show Error message if time is not valid
                MessageBox.Show("Please enter valid time in seconds");
            }
        }

        private void exitButton_Click(object sender, EventArgs e)
        {
            //Close the form
            this.Close();
        }
    }
}
