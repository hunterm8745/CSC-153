﻿/**
* March 07, 2018
* CSC 153
* Matthew Hunter, David Edwards, Cameron Scott
* Display cost of registration, lodging, and total cost based upon selected items
* 
* Code and gui: Matthew Hunter
* Psudo Code: David Edwards
* Flow Chart: Cameron Scott
*/
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace M3HW3_Group1
{
    public partial class Form1 : Form
    {
        //Initialize all variables needed
        public int registration;
        public int days;
        public int lodging;
        public int lodgingTotal;
        public int total;
        public Form1()
        {
            InitializeComponent();
        }

        private void calculateButton_Click(object sender, EventArgs e)
        {
            //Find selected item in workshopListBox then set variables bassed upon selection
            switch (workshopListBox.SelectedIndex)
            {
                case 0:
                    days = 3;
                    registration = 1000;
                    break;
                case 1:
                    days = 3;
                    registration = 800;
                    break;
                case 2:
                    days = 3;
                    registration = 1500;
                    break;
                case 3:
                    days = 5;
                    registration = 1300;
                    break;
                case 4:
                    days = 1;
                    registration = 500;
                    break;
                default:
                    MessageBox.Show("Please Select Workshop.");
                    break;
            }

            //Find selected item in locationListBox then set variables bassed upon selection
            switch (locationListBox.SelectedIndex)
            {
                case 0:
                    lodging = 150;
                    break;
                case 1:
                    lodging = 225;
                    break;
                case 2:
                    lodging = 175;
                    break;
                case 3:
                    lodging = 300;
                    break;
                case 4:
                    lodging = 175;
                    break;
                case 5:
                    lodging = 150;
                    break;
                default:
                    MessageBox.Show("Please Select Location of Workshop.");
                    break;
            }

            //Calculate total lodging cost then total cost
            lodgingTotal = lodging * days;
            total = registration + lodgingTotal;

            //Display required variables
            registrationLabel.Text = registration.ToString();
            lodgingLabel.Text = lodgingTotal.ToString();
            totalLabel.Text = total.ToString();
        }

        private void exitButton_Click(object sender, EventArgs e)
        {
            //Close the form
            this.Close();
        }
    }
}
