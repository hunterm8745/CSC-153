﻿/**
* January 24, 2018
* CSC 153
* Matthew Hunter
* Say "Good Morning" in different languages
*/



using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace M1T2_Hunterm8745
{
    public partial class instructionLabel : Form
    {
        public instructionLabel()
        {
            InitializeComponent();
        }

        //Display italian good morning
        private void italianButton_Click(object sender, EventArgs e)
        {
            translationLabel.Text = "Buongiorno";
        }

        //Display spanish good morning
        private void spanishButton_Click(object sender, EventArgs e)
        {
            translationLabel.Text = "Buenos Dias";
        }

        //Display german good morning
        private void germanButton_Click(object sender, EventArgs e)
        {
            translationLabel.Text = "Guten Morgen";
        }
    }
}
