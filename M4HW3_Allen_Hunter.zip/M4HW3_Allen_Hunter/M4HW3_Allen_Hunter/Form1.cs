﻿/* 
* Nicholas M. Allen, Matthew Hunter
* CSC 153
* 3/21/2018
* Random Number File Writer
*/

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;


namespace M4HW3_Allen_Hunter
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            int nums;
            int amountOfNums;

            

            StreamWriter outputFile;

            if (saveFileDialog1.ShowDialog() == DialogResult.OK)
            {
                outputFile = File.CreateText(saveFileDialog1.FileName);

                int.TryParse(howManyNumbers.Text, out amountOfNums);

                Random rand = new Random();

                

                int count = 1;

                while (count <= amountOfNums)
                {
                    nums = rand.Next(101);

                    outputFile.WriteLine(nums);
                    count++;
                }

                outputFile.Close();
            }
            else
            {
                MessageBox.Show("Save File Cancelled");
            }
        }
    }
}
