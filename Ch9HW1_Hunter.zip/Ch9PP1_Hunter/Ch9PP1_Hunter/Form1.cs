﻿/**
* May 12, 2018
* CSC 153
* Matthew Hunter
* Hold and display information about entered pets
*/

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Ch9PP1_Hunter
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void GetInput(Pets pet)
        {
            //Temp to hold age
            int age;

            //Get pet name
            pet.Name = nameTextBox.Text;

            //Get pet type
            pet.Type = typeTextBox.Text;

            //Get pet age
            if (int.TryParse(ageTextBox.Text, out age))
            {
                pet.Age = age;
            }
            else
            {
                //display error message
                MessageBox.Show("Invalid Age");
            }
        }

        private void submitButton_Click(object sender, EventArgs e)
        {
            //Create a pet object
            Pets pet = new Pets();

            //Get pet data
            GetInput(pet);

            //Add entry to list box
            petListBox.Items.Add(pet.Name + ", " + pet.Type + ", " + pet.Age);

            //Clear the textBox controls
            nameTextBox.Clear();
            typeTextBox.Clear();
            ageTextBox.Clear();

            //Reset focus
            nameTextBox.Focus();
        }

        private void exitButton_Click(object sender, EventArgs e)
        {
            //Close the form
            this.Close();
        }
    }
}
