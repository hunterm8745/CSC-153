﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ch9PP1_Hunter
{
    class Pets
    {
        //fields
        private string _name;       //Hold name of pet
        private string _type;       //Hold type of pet
        private int _age;           //Hold age of pet

        //Constructor
        public Pets()
        {
            _name = "";
            _type = "";
            _age = 0;
        }

        //Name Property
        public string Name
        {
            get { return _name; }
            set { _name = value; }
        }

        //Type property
        public string Type
        {
            get { return _type; }
            set { _type = value; }
        }

        //Age property
        public int Age
        {
            get { return _age; }
            set { _age = value; }
        }

    }
}
