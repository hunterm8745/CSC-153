﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ch9PP2_Hunter
{
    class Car
    {
        //Fields
        private string _year;    //Hold Car's Year
        private string _make;    //Hold Car's Make
        private int _speed;      //Hold Car's Speed

        //Create Constructor
        public Car()
        {
            _year = "";
            _make = "";
            _speed = 0;
        }


        //Year property
        public string Year
        {
            get { return _year; }
            set { _year = value; }
        }

        //Make property
        public string Make
        {
            get { return _make; }
            set { _make = value; }
        }

        //Speed property
        public int speed
        {
            get { return _speed; }
            set { _speed = value; }
        }

        //Accelerate Method
        public int Accelerate()
        {
            _speed += 5;

            return _speed;
        }

        //Break method
        public int Break()
        {
            _speed -= 5;

            return _speed;
        }
    }
}
