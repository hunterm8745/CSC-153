﻿/**
* May 12, 2018
* CSC 153
* Matthew Hunter
* Hold and display car info and track its speed
*/

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Ch9PP2_Hunter
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        //Create a car object
        Car car = new Car();

        int speed = 0;
        private void GetCarData(Car car)
        {
            //Temp Variable to hold the year
            int year;

            //get car make
            car.Make = makeTextBox.Text;

            //get year
            if (int.TryParse(yearTextBox.Text,out year))
            {
                car.Year = year.ToString();
            }
            else
            {
                //display an error message
                MessageBox.Show("Invalid Price");
            }
        }

        private void submitButton_Click(object sender, EventArgs e)
        {
            //get the car data
            GetCarData(car);

            //Display the make and year
            makeYearLabel.Text = car.Year + " " + car.Make;
        }

        private void accelerateButton_Click(object sender, EventArgs e)
        {
            //Call accelerate function from Car()
            speedLabel.Text = car.Accelerate().ToString();
        }

        private void breakButton_Click(object sender, EventArgs e)
        {
            //Check if speed is 0
            if (int.Parse(speedLabel.Text) > 0)
            {
                //Call break function from Car()
                speedLabel.Text = car.Break().ToString();
            }
            else
            {
                //Display error message
                MessageBox.Show("Cannot go slower than 0.");
            }
        }

        private void clearButton_Click(object sender, EventArgs e)
        {
            //Clear all applicable items in form
            yearTextBox.Clear();
            makeTextBox.Clear();
            makeYearLabel.Text = "";
            speedLabel.Text = "0";

            //reset focus
            yearTextBox.Focus();
        }

        private void exitButton_Click(object sender, EventArgs e)
        {
            //close the form
            this.Close();
        }
    }
}
