﻿/**
* January 24, 2018
* CSC 153
* Matthew Hunter
* Show "Hello World" text
*/

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace M1T1_Hunterm8745
{
    public partial class form1 : Form
    {
        public form1()
        {
            InitializeComponent();
        }

        private void messageButton_Click(object sender, EventArgs e)
        {
            // Display Hello World
            MessageBox.Show("Hello World");
        }
    }
}
