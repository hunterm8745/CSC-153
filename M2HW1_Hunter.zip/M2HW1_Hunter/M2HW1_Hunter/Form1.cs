﻿/**
* Febuary 11, 2018
* CSC 153
* Matthew Hunter
* Format a persons name in several ways
*/

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace M2HW1_Hunter
{
    public partial class Name : Form
    {
        public Name()
        {
            InitializeComponent();
        }

        public String firstName;       //Hold First Name
        public String middleName;      //Hold Middle Name
        public String lastName;        //Hold Last Name
        public String title;           //Hold Title

        private void format1Button_Click(object sender, EventArgs e)
        {
            try
            {
                //Assign first name
                firstName = firstNameTextBox.Text;

                //Assign middle name
                middleName = middleNameTextBox.Text;

                //Assign last name
                lastName = lastNameTextBox.Text;

                //Assign title
                title = titleTextBox.Text;

                //Display specified formated name
                formattedLabel.Text = title + " " + firstName + " " + middleName + " " + lastName;
            }
            catch (Exception ex)
            {
                //Display default error message
                MessageBox.Show(ex.Message);
            }
        }

        private void format2Button_Click(object sender, EventArgs e)
        {
            try
            {
                //Assign first name
                firstName = firstNameTextBox.Text;

                //Assign middle name
                middleName = middleNameTextBox.Text;

                //Assign last name
                lastName = lastNameTextBox.Text;

                //Display specified formated name
                formattedLabel.Text = firstName + " " + middleName + " " + lastName;
            }
            catch (Exception ex)
            {
                //Display default error message
                MessageBox.Show(ex.Message);
            }
        }

        private void format3Button_Click(object sender, EventArgs e)
        {
            try
            {
                //Assign first name
                firstName = firstNameTextBox.Text;

                //Assign last name
                lastName = lastNameTextBox.Text;

                //Display specified formated name
                formattedLabel.Text = firstName + " " + lastName;
            }
            catch (Exception ex)
            {
                //Display default error message
                MessageBox.Show(ex.Message);
            }
        }

        private void Format4Button_Click(object sender, EventArgs e)
        {
            try
            {
                //Assign first name
                firstName = firstNameTextBox.Text;

                //Assign middle name
                middleName = middleNameTextBox.Text;

                //Assign last name
                lastName = lastNameTextBox.Text;

                //Assign title
                title = titleTextBox.Text;

                //Display specified formated name
                formattedLabel.Text = lastName + ", " + firstName + " " + middleName + ", " + title;
            }
            catch (Exception ex)
            {
                //Display default error message
                MessageBox.Show(ex.Message);
            }
        }

        private void format5Button_Click(object sender, EventArgs e)
        {
            try
            {
                //Assign first name
                firstName = firstNameTextBox.Text;

                //Assign middle name
                middleName = middleNameTextBox.Text;

                //Assign last name
                lastName = lastNameTextBox.Text;

                //Display specified formated name
                formattedLabel.Text = lastName + ", " + firstName + " " + middleName;
            }
            catch (Exception ex)
            {
                //Display default error message
                MessageBox.Show(ex.Message);
            }
        }

        private void format6Button_Click(object sender, EventArgs e)
        {
            try
            {
                //Assign first name
                firstName = firstNameTextBox.Text;

                //Assign last name
                lastName = lastNameTextBox.Text;

                //Display specified formated name
                formattedLabel.Text = lastName + ", " + firstName;
            }
            catch (Exception ex)
            {
                //Display default error message
                MessageBox.Show(ex.Message);
            }
        }

        private void clearButton_Click(object sender, EventArgs e)
        {
            //Clear all input and output controlls
            firstNameTextBox.Text = "";
            middleNameTextBox.Text = "";
            lastNameTextBox.Text = "";
            titleTextBox.Text = "";
            formattedLabel.Text = "";
        }

        private void exitButton_Click(object sender, EventArgs e)
        {
            //Exit Program
            this.Close();
        }
    }
}
