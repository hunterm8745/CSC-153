﻿namespace M2HW1_Hunter
{
    partial class Name
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.firstNameLabel = new System.Windows.Forms.Label();
            this.middleNameLabel = new System.Windows.Forms.Label();
            this.lastNameLabel = new System.Windows.Forms.Label();
            this.titleLabel = new System.Windows.Forms.Label();
            this.firstNameTextBox = new System.Windows.Forms.TextBox();
            this.middleNameTextBox = new System.Windows.Forms.TextBox();
            this.lastNameTextBox = new System.Windows.Forms.TextBox();
            this.titleTextBox = new System.Windows.Forms.TextBox();
            this.formattedLabel = new System.Windows.Forms.Label();
            this.format1Button = new System.Windows.Forms.Button();
            this.format2Button = new System.Windows.Forms.Button();
            this.format3Button = new System.Windows.Forms.Button();
            this.Format4Button = new System.Windows.Forms.Button();
            this.format5Button = new System.Windows.Forms.Button();
            this.format6Button = new System.Windows.Forms.Button();
            this.instructionLable = new System.Windows.Forms.Label();
            this.exitButton = new System.Windows.Forms.Button();
            this.clearButton = new System.Windows.Forms.Button();
            this.nameGroupBox = new System.Windows.Forms.GroupBox();
            this.backgroundWorker1 = new System.ComponentModel.BackgroundWorker();
            this.nameGroupBox.SuspendLayout();
            this.SuspendLayout();
            // 
            // firstNameLabel
            // 
            this.firstNameLabel.AutoSize = true;
            this.firstNameLabel.Location = new System.Drawing.Point(145, 35);
            this.firstNameLabel.Name = "firstNameLabel";
            this.firstNameLabel.Size = new System.Drawing.Size(60, 13);
            this.firstNameLabel.TabIndex = 0;
            this.firstNameLabel.Text = "First Name:";
            // 
            // middleNameLabel
            // 
            this.middleNameLabel.AutoSize = true;
            this.middleNameLabel.Location = new System.Drawing.Point(133, 61);
            this.middleNameLabel.Name = "middleNameLabel";
            this.middleNameLabel.Size = new System.Drawing.Size(72, 13);
            this.middleNameLabel.TabIndex = 1;
            this.middleNameLabel.Text = "Middle Name:";
            // 
            // lastNameLabel
            // 
            this.lastNameLabel.AutoSize = true;
            this.lastNameLabel.Location = new System.Drawing.Point(144, 87);
            this.lastNameLabel.Name = "lastNameLabel";
            this.lastNameLabel.Size = new System.Drawing.Size(61, 13);
            this.lastNameLabel.TabIndex = 2;
            this.lastNameLabel.Text = "Last Name:";
            // 
            // titleLabel
            // 
            this.titleLabel.AutoSize = true;
            this.titleLabel.Location = new System.Drawing.Point(108, 113);
            this.titleLabel.Name = "titleLabel";
            this.titleLabel.Size = new System.Drawing.Size(100, 26);
            this.titleLabel.TabIndex = 3;
            this.titleLabel.Text = "        Preferred Title:\r\n(ex, Mr., Mrs., Ms.)";
            // 
            // firstNameTextBox
            // 
            this.firstNameTextBox.Location = new System.Drawing.Point(211, 32);
            this.firstNameTextBox.Name = "firstNameTextBox";
            this.firstNameTextBox.Size = new System.Drawing.Size(100, 20);
            this.firstNameTextBox.TabIndex = 4;
            // 
            // middleNameTextBox
            // 
            this.middleNameTextBox.Location = new System.Drawing.Point(211, 58);
            this.middleNameTextBox.Name = "middleNameTextBox";
            this.middleNameTextBox.Size = new System.Drawing.Size(100, 20);
            this.middleNameTextBox.TabIndex = 5;
            // 
            // lastNameTextBox
            // 
            this.lastNameTextBox.Location = new System.Drawing.Point(211, 84);
            this.lastNameTextBox.Name = "lastNameTextBox";
            this.lastNameTextBox.Size = new System.Drawing.Size(100, 20);
            this.lastNameTextBox.TabIndex = 6;
            // 
            // titleTextBox
            // 
            this.titleTextBox.Location = new System.Drawing.Point(211, 110);
            this.titleTextBox.Name = "titleTextBox";
            this.titleTextBox.Size = new System.Drawing.Size(100, 20);
            this.titleTextBox.TabIndex = 7;
            // 
            // formattedLabel
            // 
            this.formattedLabel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.formattedLabel.Location = new System.Drawing.Point(6, 169);
            this.formattedLabel.Name = "formattedLabel";
            this.formattedLabel.Size = new System.Drawing.Size(449, 36);
            this.formattedLabel.TabIndex = 8;
            this.formattedLabel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // format1Button
            // 
            this.format1Button.Location = new System.Drawing.Point(65, 271);
            this.format1Button.Name = "format1Button";
            this.format1Button.Size = new System.Drawing.Size(120, 39);
            this.format1Button.TabIndex = 9;
            this.format1Button.Text = "Title First Middle Last";
            this.format1Button.UseVisualStyleBackColor = true;
            this.format1Button.Click += new System.EventHandler(this.format1Button_Click);
            // 
            // format2Button
            // 
            this.format2Button.Location = new System.Drawing.Point(191, 271);
            this.format2Button.Name = "format2Button";
            this.format2Button.Size = new System.Drawing.Size(120, 39);
            this.format2Button.TabIndex = 10;
            this.format2Button.Text = "First Middle Last";
            this.format2Button.UseVisualStyleBackColor = true;
            this.format2Button.Click += new System.EventHandler(this.format2Button_Click);
            // 
            // format3Button
            // 
            this.format3Button.Location = new System.Drawing.Point(317, 271);
            this.format3Button.Name = "format3Button";
            this.format3Button.Size = new System.Drawing.Size(120, 39);
            this.format3Button.TabIndex = 11;
            this.format3Button.Text = "First Last";
            this.format3Button.UseVisualStyleBackColor = true;
            this.format3Button.Click += new System.EventHandler(this.format3Button_Click);
            // 
            // Format4Button
            // 
            this.Format4Button.Location = new System.Drawing.Point(65, 319);
            this.Format4Button.Name = "Format4Button";
            this.Format4Button.Size = new System.Drawing.Size(120, 39);
            this.Format4Button.TabIndex = 12;
            this.Format4Button.Text = "Last, First Middle, Title";
            this.Format4Button.UseVisualStyleBackColor = true;
            this.Format4Button.Click += new System.EventHandler(this.Format4Button_Click);
            // 
            // format5Button
            // 
            this.format5Button.Location = new System.Drawing.Point(191, 316);
            this.format5Button.Name = "format5Button";
            this.format5Button.Size = new System.Drawing.Size(120, 39);
            this.format5Button.TabIndex = 13;
            this.format5Button.Text = "Last, First Middle";
            this.format5Button.UseVisualStyleBackColor = true;
            this.format5Button.Click += new System.EventHandler(this.format5Button_Click);
            // 
            // format6Button
            // 
            this.format6Button.Location = new System.Drawing.Point(317, 316);
            this.format6Button.Name = "format6Button";
            this.format6Button.Size = new System.Drawing.Size(120, 39);
            this.format6Button.TabIndex = 14;
            this.format6Button.Text = "Last, First";
            this.format6Button.UseVisualStyleBackColor = true;
            this.format6Button.Click += new System.EventHandler(this.format6Button_Click);
            // 
            // instructionLable
            // 
            this.instructionLable.AutoSize = true;
            this.instructionLable.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.instructionLable.Location = new System.Drawing.Point(62, 9);
            this.instructionLable.Name = "instructionLable";
            this.instructionLable.Size = new System.Drawing.Size(388, 16);
            this.instructionLable.TabIndex = 15;
            this.instructionLable.Text = "Enter your name and click a button to have it formatted as shown!";
            // 
            // exitButton
            // 
            this.exitButton.Location = new System.Drawing.Point(213, 406);
            this.exitButton.Name = "exitButton";
            this.exitButton.Size = new System.Drawing.Size(75, 39);
            this.exitButton.TabIndex = 16;
            this.exitButton.Text = "Exit";
            this.exitButton.UseVisualStyleBackColor = true;
            this.exitButton.Click += new System.EventHandler(this.exitButton_Click);
            // 
            // clearButton
            // 
            this.clearButton.Location = new System.Drawing.Point(213, 361);
            this.clearButton.Name = "clearButton";
            this.clearButton.Size = new System.Drawing.Size(75, 39);
            this.clearButton.TabIndex = 17;
            this.clearButton.Text = "Clear";
            this.clearButton.UseVisualStyleBackColor = true;
            this.clearButton.Click += new System.EventHandler(this.clearButton_Click);
            // 
            // nameGroupBox
            // 
            this.nameGroupBox.Controls.Add(this.firstNameTextBox);
            this.nameGroupBox.Controls.Add(this.firstNameLabel);
            this.nameGroupBox.Controls.Add(this.middleNameTextBox);
            this.nameGroupBox.Controls.Add(this.middleNameLabel);
            this.nameGroupBox.Controls.Add(this.lastNameTextBox);
            this.nameGroupBox.Controls.Add(this.lastNameLabel);
            this.nameGroupBox.Controls.Add(this.titleTextBox);
            this.nameGroupBox.Controls.Add(this.titleLabel);
            this.nameGroupBox.Controls.Add(this.formattedLabel);
            this.nameGroupBox.Location = new System.Drawing.Point(24, 33);
            this.nameGroupBox.Name = "nameGroupBox";
            this.nameGroupBox.Size = new System.Drawing.Size(460, 232);
            this.nameGroupBox.TabIndex = 18;
            this.nameGroupBox.TabStop = false;
            this.nameGroupBox.Text = "Name";
            // 
            // Name
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(521, 462);
            this.Controls.Add(this.nameGroupBox);
            this.Controls.Add(this.clearButton);
            this.Controls.Add(this.exitButton);
            this.Controls.Add(this.instructionLable);
            this.Controls.Add(this.format6Button);
            this.Controls.Add(this.format5Button);
            this.Controls.Add(this.Format4Button);
            this.Controls.Add(this.format3Button);
            this.Controls.Add(this.format2Button);
            this.Controls.Add(this.format1Button);
            this.Name = "Name";
            this.Text = "Name Formatter";
            this.nameGroupBox.ResumeLayout(false);
            this.nameGroupBox.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label firstNameLabel;
        private System.Windows.Forms.Label middleNameLabel;
        private System.Windows.Forms.Label lastNameLabel;
        private System.Windows.Forms.Label titleLabel;
        private System.Windows.Forms.TextBox firstNameTextBox;
        private System.Windows.Forms.TextBox middleNameTextBox;
        private System.Windows.Forms.TextBox lastNameTextBox;
        private System.Windows.Forms.TextBox titleTextBox;
        private System.Windows.Forms.Label formattedLabel;
        private System.Windows.Forms.Button format1Button;
        private System.Windows.Forms.Button format2Button;
        private System.Windows.Forms.Button format3Button;
        private System.Windows.Forms.Button Format4Button;
        private System.Windows.Forms.Button format5Button;
        private System.Windows.Forms.Button format6Button;
        private System.Windows.Forms.Label instructionLable;
        private System.Windows.Forms.Button exitButton;
        private System.Windows.Forms.Button clearButton;
        private System.Windows.Forms.GroupBox nameGroupBox;
        private System.ComponentModel.BackgroundWorker backgroundWorker1;
    }
}

