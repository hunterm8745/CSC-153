﻿/**
* March 12, 2018
* CSC 153
* Matthew Hunter
* display everything in a txt document
*/

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace M4T2_Hunter
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void getCountriesButton_Click(object sender, EventArgs e)
        {
            try
            {
                //Declare a variable to hold a country name
                string countryName;

                //Declare a StreamReader variable
                StreamReader inputFile;

                //Open file and get a StreamReader object
                inputFile = File.OpenText("Countries.txt");

                //Clear anything in listbox
                countriesListBox.Items.Clear();

                //Read the file's contents
                while (!inputFile.EndOfStream)
                {
                    //Get country name
                    countryName = inputFile.ReadLine();

                    //Add country name to listbox
                    countriesListBox.Items.Add(countryName);
                }

                //Close File
                inputFile.Close();
            }
            catch (Exception ex)
            {
                //Display error message
                MessageBox.Show(ex.Message);
            }
        }

        private void exitButton_Click(object sender, EventArgs e)
        {
            //Close the form
            this.Close();
        }
    }
}
