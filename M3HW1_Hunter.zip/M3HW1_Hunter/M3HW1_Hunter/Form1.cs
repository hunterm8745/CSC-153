﻿/**
* Febuary 19, 2018
* CSC 153
* Matthew Hunter
* Display correct roman numeral for given number between 1 and 10
*/



using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace M3HW1_Hunter
{
    public partial class Form1 : Form
    {
        public int number;      //Hold given number
        public Form1()
        {
            InitializeComponent();
        }

        private void translateButton_Click(object sender, EventArgs e)
        {
            //Converta and assign given number
            number = int.Parse(numberTextBox.Text);

            //Create a switch to test the number variable and display the corisponding roman numeral
            switch (number)
            {
                case 1:
                    numeralLabel.Text = "I";
                    break;

                case 2:
                    numeralLabel.Text = "II";
                    break;

                case 3:
                    numeralLabel.Text = "III";
                    break;

                case 4:
                    numeralLabel.Text = "IV";
                    break;

                case 5:
                    numeralLabel.Text = "V";
                    break;

                case 6:
                    numeralLabel.Text = "VI";
                    break;

                case 7:
                    numeralLabel.Text = "VII";
                    break;

                case 8:
                    numeralLabel.Text = "VIII";
                    break;

                case 9:
                    numeralLabel.Text = "IX";
                    break;

                case 10:
                    numeralLabel.Text = "X";
                    break;

                default:
                    MessageBox.Show("Error: Please select a number between 1 and 10");
                    break;
            }
        }

        private void clearButton_Click(object sender, EventArgs e)
        {
            //Set all input and output to blank
            numberTextBox.Text = "";
            numeralLabel.Text = "";
        }

        private void exitButton_Click(object sender, EventArgs e)
        {
            //Close the form
            this.Close();
        }
    }
}

