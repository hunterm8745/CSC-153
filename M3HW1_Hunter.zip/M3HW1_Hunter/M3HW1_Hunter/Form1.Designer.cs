﻿namespace M3HW1_Hunter
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.exitButton = new System.Windows.Forms.Button();
            this.clearButton = new System.Windows.Forms.Button();
            this.translateButton = new System.Windows.Forms.Button();
            this.numeralLabel = new System.Windows.Forms.Label();
            this.romanLabel = new System.Windows.Forms.Label();
            this.numberTextBox = new System.Windows.Forms.TextBox();
            this.numberLabel = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // exitButton
            // 
            this.exitButton.Location = new System.Drawing.Point(152, 139);
            this.exitButton.Name = "exitButton";
            this.exitButton.Size = new System.Drawing.Size(52, 23);
            this.exitButton.TabIndex = 13;
            this.exitButton.Text = "Exit";
            this.exitButton.UseVisualStyleBackColor = true;
            this.exitButton.Click += new System.EventHandler(this.exitButton_Click);
            // 
            // clearButton
            // 
            this.clearButton.Location = new System.Drawing.Point(94, 139);
            this.clearButton.Name = "clearButton";
            this.clearButton.Size = new System.Drawing.Size(52, 23);
            this.clearButton.TabIndex = 12;
            this.clearButton.Text = "Clear";
            this.clearButton.UseVisualStyleBackColor = true;
            this.clearButton.Click += new System.EventHandler(this.clearButton_Click);
            // 
            // translateButton
            // 
            this.translateButton.Location = new System.Drawing.Point(94, 81);
            this.translateButton.Name = "translateButton";
            this.translateButton.Size = new System.Drawing.Size(113, 52);
            this.translateButton.TabIndex = 11;
            this.translateButton.Text = "Translate Number to Roman Numeral";
            this.translateButton.UseVisualStyleBackColor = true;
            this.translateButton.Click += new System.EventHandler(this.translateButton_Click);
            // 
            // numeralLabel
            // 
            this.numeralLabel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.numeralLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.numeralLabel.Location = new System.Drawing.Point(219, 45);
            this.numeralLabel.Name = "numeralLabel";
            this.numeralLabel.Size = new System.Drawing.Size(49, 20);
            this.numeralLabel.TabIndex = 10;
            this.numeralLabel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // romanLabel
            // 
            this.romanLabel.AutoSize = true;
            this.romanLabel.Location = new System.Drawing.Point(128, 48);
            this.romanLabel.Name = "romanLabel";
            this.romanLabel.Size = new System.Drawing.Size(89, 13);
            this.romanLabel.TabIndex = 9;
            this.romanLabel.Text = "Roman Numeral: ";
            // 
            // numberTextBox
            // 
            this.numberTextBox.Location = new System.Drawing.Point(219, 16);
            this.numberTextBox.Name = "numberTextBox";
            this.numberTextBox.Size = new System.Drawing.Size(49, 20);
            this.numberTextBox.TabIndex = 8;
            this.numberTextBox.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // numberLabel
            // 
            this.numberLabel.AutoSize = true;
            this.numberLabel.Location = new System.Drawing.Point(12, 19);
            this.numberLabel.Name = "numberLabel";
            this.numberLabel.Size = new System.Drawing.Size(205, 13);
            this.numberLabel.TabIndex = 7;
            this.numberLabel.Text = "Enter a number whole between 1 and 10: ";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(289, 179);
            this.Controls.Add(this.exitButton);
            this.Controls.Add(this.clearButton);
            this.Controls.Add(this.translateButton);
            this.Controls.Add(this.numeralLabel);
            this.Controls.Add(this.romanLabel);
            this.Controls.Add(this.numberTextBox);
            this.Controls.Add(this.numberLabel);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button exitButton;
        private System.Windows.Forms.Button clearButton;
        private System.Windows.Forms.Button translateButton;
        private System.Windows.Forms.Label numeralLabel;
        private System.Windows.Forms.Label romanLabel;
        private System.Windows.Forms.TextBox numberTextBox;
        private System.Windows.Forms.Label numberLabel;
    }
}

