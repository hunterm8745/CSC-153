﻿/**
* Febuary 26, 2018
* CSC 153
* Matthew Hunter
* Calculate cost, with or without discount, of units purchased
*/

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace M3HW2_Hunter
{
    public partial class Form1 : Form
    {
        //Initialize all variables needed
        public const double COST = 99;
        public double units;
        public double discount;
        public double total;
        public Form1()
        {
            InitializeComponent();
        }

        private void calculateButton_Click(object sender, EventArgs e)
        {
            //Convert and assign units purchased
            units = int.Parse(purchaseTextBox.Text);

            //Test ammount of units purchased to find related discount if any then calculate total
            if (units < 10)
            {
                discount = 0;
                total = units * (COST);
            }
            else if (units >= 10 && units <= 19)
            {
                discount = .2;
                total = units * (COST * discount);
            }
            else if (units >= 20 && units <= 49)
            {
                discount = .3;
                total = units * (COST * discount);
            }
            else if (units >= 50 && units <= 99)
            {
                discount = .4;
                total = units * (COST * discount);
            }
            else if (units >= 100)
            {
                discount = .5;
                total = units * (COST * discount);
            }

            //convert and display both discount and total cost
            discountLabel.Text = (discount * 100).ToString();
            totalLabel.Text = total.ToString();
        }

        private void clearButton_Click(object sender, EventArgs e)
        {
            //Clear all relative text boxes
            purchaseTextBox.Text = "";
            discountLabel.Text = "";
            totalLabel.Text = "";
        }

        private void exitButton_Click(object sender, EventArgs e)
        {
            //Close the form
            this.Close();
        }
    }
}
