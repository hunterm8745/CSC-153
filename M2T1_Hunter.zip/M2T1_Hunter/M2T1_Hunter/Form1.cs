﻿/**
* Febuary 12, 2018
* CSC 153
* Matthew Hunter
* Calculate Cars Miles Per Gallon
*/

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace M2T1_Hunter
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void calculateButton_Click(object sender, EventArgs e)
        {
            double miles;       //Hold miles driven
            double gallons;     //Hold gallons used
            double mpg;         //Hold MPG

            //assign miles driven and change it to a double
            miles = double.Parse(milesTextBox.Text);

            //assign gallons used and change it to a double
            gallons = double.Parse(gallonsTextBox.Text);

            //Calculate MPG
            mpg = miles / gallons;

            //Display MPG
            mpgLabel.Text = mpg.ToString();
        }

        private void exitButton_Click(object sender, EventArgs e)
        {
            //Close the program
            this.Close();
        }
    }
}
